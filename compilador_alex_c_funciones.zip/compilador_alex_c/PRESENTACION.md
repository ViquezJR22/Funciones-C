# Presentación del compilador ALEX

Duración sugerida: 8 a 9 minutos. Dos partes: características del lenguaje y demostración. Después, las preguntas de dominio de conceptos.

## Parte 1: Características de ALEX (2 minutos)

Decir con mis palabras:

1. **Qué es:** un lenguaje con palabras en español (`dato`, `entero`, `verdadero`) para que el código se lea fácil.
2. **Declaración:** `dato nombre: tipo;` o con valor inicial `dato nombre: tipo = valor;`. Toda instrucción termina con `;`.
3. **Asignación:** `nombre = expresion;`. La variable debe existir y el valor debe ser del mismo tipo.
4. **Cuatro tipos:** entero, decimal, texto y logico. El tipo se reconoce por cómo está escrito el valor: `5` es entero, `5.0` es decimal, `"25"` es texto.
5. **Compatibilidad:** un entero cabe en un decimal, pero un decimal no cabe en un entero.
6. **Nombres:** empiezan con letra o `_`, distinguen mayúsculas, no pueden ser palabras reservadas ni repetirse.
7. **Valores por defecto:** 0, 0.0, texto vacío y falso.
8. **Prohibido:** asignaciones encadenadas (`a = b = 3;`).
9. **Operadores:** `+ - * /` y paréntesis, que agregué porque mis ejemplos ya usaban `edad + 1`.
10. **Funciones propias:** `funcion suma(a: entero, b: entero): entero { retornar a + b; }`. El tipo de retorno es opcional: sin él, la función solo hace algo y no devuelve nada.
11. **Ámbito:** cada función tiene su propio espacio. Ve sus parámetros y sus variables locales, pero no las globales; lo que necesita lo recibe como parámetro.
12. **Funciones predefinidas:** `mostrar`, `longitud`, `mayusculas`, `redondear`, `absoluto`, `agregar`, `quitar`, y también de números (`minimo`, `maximo`, `raiz`, `potencia`) y de textos (`minusculas`, `invertir`, `contiene`, `subtexto`, `aTexto`). Con `mostrar` el lenguaje por fin tiene salida en pantalla.
13. **Reglas de las funciones:** se definen antes de usarse, los argumentos deben coincidir en cantidad y tipo, y si declaran un tipo deben retornar un valor de ese tipo en todos sus caminos. No puede haber código después de un `retornar` que siempre se ejecuta.
14. **Condicionales:** `si (condicion) { ... } sino { ... }`. La condición va entre paréntesis y debe ser de tipo `logico`. También acepta `sino si` para varias opciones.
15. **Comparaciones:** `==  !=  <  >  <=  >=`, y siempre dan un valor `logico`. Los de orden (`<`, `>`, `<=`, `>=`) solo comparan números; `==` y `!=` comparan dos valores del mismo tipo.
16. **Ámbito de bloque:** una variable declarada dentro de un bloque `si` o `sino` solo existe ahí. El bloque ve las variables que lo rodean y puede modificarlas.
17. **Recursión:** ahora que hay `si`, una función puede llamarse a sí misma con un caso base (por ejemplo, el factorial). Hay un límite de 200 llamadas anidadas para detectar un caso base que falta.
18. **Arreglos:** una lista de valores del mismo tipo. Se declaran con `tipo[]` (`entero[]`, `decimal[]`, `texto[]`, `logico[]`) y un literal entre corchetes: `dato notas: decimal[] = [8.5, 9, 7.25];`. Sin valor inicial empiezan vacíos.
19. **Índices:** `notas[0]` lee un elemento y `notas[1] = 10;` lo cambia. El primer elemento es el 0, el índice debe ser entero y, si se sale del rango, la ejecución se detiene con un error claro.
20. **Funciones de arreglos:** `agregar(arreglo, valor)` agrega al final (push), `quitar(arreglo)` saca el último y lo devuelve (pop) y `longitud(arreglo)` da la cantidad. Los arreglos se pasan por referencia, así que una función puede modificarlos.
21. **Reglas de los arreglos:** todos los elementos son del mismo tipo, no hay arreglos dentro de arreglos, no se comparan con `==`, y un `entero[]` no cabe en un `decimal[]` (un literal como `[1, 2]` sí se adapta al tipo donde se guarda).
22. **Escrito en C:** el compilador completo está en un solo archivo, `alex.c`, y se compila con `make`.

## Parte 2: Demostración (4 minutos)

| Paso | Comando | Qué señalar |
|---|---|---|
| 1 | Mostrar `ejemplos/ok.alex` | Los cuatro tipos, una asignación con expresión y un comentario |
| 2 | `./alex ejemplos/ok.alex --tokens` | Tabla de tokens, árbol AST, AST Table, ejecución paso a paso y tabla de símbolos |
| 3 | Señalar la tabla de símbolos | `edad` pasa de 21 a 22 y `promedio` empieza en 0.0 por defecto |
| 4 | `./alex ejemplos/err_lexico.alex` | Carácter `@`, decimal `3.` y texto sin cerrar |
| 5 | `./alex ejemplos/err_sintactico.alex` | Falta `;`, falta `:`, `a = b = 3;`, palabra reservada como nombre |
| 6 | `./alex ejemplos/err_semantico.alex` | Variable no declarada, redeclarada, decimal en entero. No se ejecuta nada |
| 7 | Mostrar `ejemplos/funciones.alex` | Tres funciones propias (una con retorno entero, una con decimal, una sin retorno) y las cinco predefinidas |
| 8 | `./alex ejemplos/funciones.alex` | El nodo `Funcion` y `Llamada` en el árbol, "SALIDA DEL PROGRAMA", y la tabla de símbolos con la columna **Ámbito** (`resultado` vive solo en `suma`) junto con la tabla de funciones |
| 9 | `./alex ejemplos/err_func_semantico.alex` | Argumentos de más o de menos, tipo de argumento incorrecto, función no definida, `retornar` fuera de función, código inalcanzable y una función que no ve una variable global |
| 10 | `./alex ejemplos/err_func_sintactico.alex` | Paréntesis sin cerrar, función dentro de otra, coma sobrante y falta de `}` |
| 11 | Mostrar `ejemplos/condicionales.alex` | `si` con `sino`, `si` sin `sino`, `sino si`, una función con `si` y `sino` que retorna en los dos caminos, y el factorial recursivo |
| 12 | `./alex ejemplos/condicionales.alex` | En el árbol, los nodos `Si` y `Bloque`; en la ejecución, qué rama tomó cada `si` ("condición verdadera → se ejecuta el bloque «si»"); en la tabla de símbolos, `mensaje` con ámbito `global/si@49` |
| 13 | `./alex ejemplos/err_si_semantico.alex` | Condición que no es lógica, comparar texto con entero, variable de bloque usada afuera, función que no retorna en todos los caminos y código inalcanzable |
| 14 | `./alex ejemplos/err_si_sintactico.alex` | Falta de paréntesis, falta de `{`, `sino` suelto y falta de `}` |
| 15 | Mostrar `ejemplos/arreglos.alex` | Arreglos de decimales, textos y enteros; índices; `agregar`, `quitar` y `longitud`; una función que recibe un arreglo y otra que lo devuelve |
| 16 | `./alex ejemplos/arreglos.alex` | En el árbol, los nodos `LiteralArreglo`, `Indice` y `AsignacionIndice`; en la ejecución, cómo cambia `notas` línea por línea; en la tabla de símbolos, el valor inicial y el final de cada arreglo |
| 17 | `./alex ejemplos/err_arr_semantico.alex` | Elemento decimal en un `entero[]`, índice que no es entero, corchetes sobre un entero, `agregar` con el tipo equivocado, `==` entre arreglos |
| 18 | `./alex ejemplos/err_arr_sintactico.alex` | Falta de `]` en el tipo, en el literal y en el índice, y una coma de más |
| 19 | `./alex ejemplos/mas_funciones.alex` | Las funciones nuevas: `minimo` y `maximo` (el tipo del resultado depende de los argumentos), `raiz`, `potencia`, `invertir`, `subtexto`, `contiene` y `aTexto`, usadas también dentro de una función propia |
| 20 | `./alex ejemplos/err_funciones_pred.alex` | Argumentos de más o de menos, de tipo equivocado, y `raiz` como nombre de variable (reservado) |
| 21 | `./alex ejemplos/err_arr_ejecucion.alex` | El programa está bien escrito pero falla al ejecutarse: índice 3 en un arreglo de 3 elementos |

Para mostrar dónde vive cada fase en el código, buscar con `Ctrl+F` en `alex.c`: `analizar_lexico`, `programa` (parser), `sem_sentencia` (semántico), `ejecutar`.

## Parte 3: Dominio de conceptos (preguntas probables)

**¿Qué hace cada fase?**
- Léxica: lee el texto carácter por carácter y lo agrupa en tokens.
- Sintáctica: comprueba que los tokens sigan la gramática y construye el árbol.
- Semántica: comprueba el significado (declaraciones, tipos, duplicados).
- Ejecución: recorre el árbol y calcula los valores.

**¿Qué es un token, un lexema y un patrón?**
Un lexema es el texto concreto (`edad`), un token es su categoría (`IDENT`) y el patrón es la regla que lo describe (empieza con letra o `_`, sigue con letras, números o `_`).

**¿Qué es una gramática libre de contexto?**
Un conjunto de reglas de producción que describe qué programas son válidos. La mía está escrita en notación BNF en el `README.md`.

**¿Qué tipo de parser usé?**
Un descendente recursivo: una función por cada regla de la gramática. Decide con solo mirar el token actual (por ejemplo, `dato` inicia una declaración y un identificador inicia una asignación), por eso no necesita retroceder.

**¿Cómo resuelvo la precedencia de operadores?**
Con la propia gramática. `*` y `/` están en `termino`, un nivel más profundo que `+` y `-` en `suma`, y las comparaciones están en `expresion`, el nivel más alto. Por eso `a + 1 > b * 2` se calcula como `(a + 1) > (b * 2)`: primero lo aritmético y al final la comparación. Los `while` de cada nivel del parser hacen que se evalúen de izquierda a derecha.

**¿Qué es el AST y en qué se diferencia del árbol de derivación?**
El AST guarda solo lo esencial. No tiene nodos para `;`, `:` ni paréntesis, porque su efecto ya está en la forma del árbol. Un árbol de derivación tendría un nodo por cada regla aplicada.

**¿Qué es la AST Table?**
Es el mismo árbol en forma de tabla: cada nodo con un ID, su tipo, valor, tipo de dato, padre, hijos y línea.

**¿Qué guarda la tabla de símbolos y cuándo se llena?**
Una entrada por variable o parámetro: nombre, tipo, clase, ámbito, línea de declaración, asignaciones, lecturas, valor inicial y valor final. Se llena durante el análisis semántico, y los valores de las globales se completan al ejecutar. Además hay una tabla de funciones con su firma y las veces que se llamaron.

**¿Qué verifica el análisis semántico que el sintáctico no puede?**
Que la variable exista, que no se declare dos veces y que los tipos sean compatibles. Una instrucción como `edad = "veinte";` está bien escrita (la gramática la acepta) pero no tiene sentido porque `edad` es entera.

**¿Qué es la coerción de tipos?**
Una conversión automática. En ALEX solo hay una: un entero se convierte a decimal (`precio = 5;` guarda `5.0`). La contraria no existe porque perdería información.

**¿Cómo manejo los errores?**
Cada error indica fase, línea, columna y la línea de código con una flecha. El parser, al fallar, salta hasta el siguiente `;` y sigue revisando (recuperación en modo pánico), por eso reporta varios errores en una sola corrida. Un error en una fase detiene las siguientes.

**¿Es un compilador o un intérprete?**
Mi proyecto cubre el *front-end* de un compilador (léxico, sintáctico y semántico) y además ejecuta el AST directamente, como un intérprete. No genera código máquina ni bytecode. Ese sería el siguiente paso: una fase de generación de código a partir del mismo AST.

**¿Qué diferencia hay entre parámetro y argumento?**
El parámetro es la variable que aparece en la definición (`a: entero` en `funcion suma(a: entero, b: entero)`). El argumento es el valor que se pasa en la llamada (`suma(2, 3)`). El semántico comprueba que coincidan en cantidad y en tipo.

**¿Qué es un ámbito (scope) y cómo lo manejo?**
Es la zona del programa donde una variable existe. En ALEX hay un ámbito global y uno por cada función. La tabla de símbolos guarda cada variable con su ámbito, así que `x` global y `x` local pueden convivir sin chocar. Una función no ve las variables globales; lo que necesita lo recibe por parámetros.

**¿Qué pasa cuando se ejecuta una llamada?**
Primero se calculan los argumentos. Luego se crea un ámbito nuevo con los parámetros ya cargados, se ejecuta el cuerpo, y `retornar` sale de la función con su valor. El valor reemplaza a la llamada dentro de la expresión.

**¿Cómo funciona un `si` / `sino` en el compilador?**
En el parser, `si` es una regla de la gramática: lee la condición entre paréntesis, un bloque y, si viene `sino`, otro bloque (o un `si` más, para `sino si`). En el AST queda un nodo `Si` con tres hijos: la condición, el bloque `entonces` y, opcionalmente, el bloque `sino`. El semántico comprueba que la condición sea `logico` y analiza cada bloque en su propio ámbito. En la ejecución se evalúa la condición y se corre solo uno de los dos bloques.

**¿Cómo sabe el compilador que una función retorna en todos sus caminos?**
Cada sentencia informa si siempre termina en un `retornar`. Un `retornar` sí; un `si` solo si tiene `sino` y los dos bloques retornan; cualquier otra instrucción no. Si la lista de instrucciones de la función no retorna siempre y la función declara un tipo, hay error. Por ejemplo, un `si` sin `sino` que retorna no alcanza, pero un `retornar` después de él sí.

**¿Qué diferencia hay entre el ámbito de una función y el de un bloque?**
Una función solo ve sus parámetros y sus variables locales; no ve las globales. Un bloque (`si` o `sino`) sí ve las variables que lo rodean y puede modificarlas, pero lo que declara dentro desaparece al terminar el bloque. En la tabla de símbolos aparece con un ámbito como `global/si@49` (el bloque del `si` de la línea 49).

**¿Qué pasa si una variable de un bloque se declara con el nombre de una externa?**
Es válido: la del bloque tapa a la externa (sombreado) solo dentro del bloque. Al salir, la externa conserva su valor. Dentro del mismo ámbito, en cambio, no se puede declarar dos veces el mismo nombre.

**¿Cómo manejo la recursión?**
Una función se registra antes de analizar su cuerpo, así que puede llamarse a sí misma. El `si` aporta el caso base, como en el factorial de `ejemplos/condicionales.alex`. Si el caso base falta, la ejecución se detiene a las 200 llamadas anidadas con el mensaje "Recursión demasiado profunda", en vez de colgarse.

**¿Cómo sabe el semántico qué tipo devuelve una llamada?**
Busca la función en la tabla de funciones y toma su tipo de retorno. En `absoluto` el retorno depende del argumento: entero si recibe entero y decimal si recibe decimal. Una función sin tipo de retorno no se puede usar dentro de una expresión.

**¿Cómo funcionan los arreglos en el compilador?**
En la gramática, el tipo ahora puede llevar `[]` (`tipo ::= TIPO [ "[" "]" ]`), hay un literal `[a, b, c]` y se pueden usar corchetes después de una variable (`lista[0]`) o al asignar (`lista[0] = 5;`). En el AST aparecen tres nodos nuevos: `LiteralArreglo`, `Indice` y `AsignacionIndice`. El semántico comprueba que lo indexado sea un arreglo, que el índice sea entero y que cada elemento sea del tipo del arreglo. En la ejecución un arreglo es una lista que crece sola, y se revisa el rango en cada acceso.

**¿Cómo representas un tipo arreglo?**
Un tipo es un número: 1 a 4 para `entero`, `decimal`, `texto` y `logico`. Sumarle 8 lo convierte en arreglo, así que `entero[]` es 9 y `texto[]` es 11. Con una operación se sabe si es arreglo y de qué tipo son sus elementos.

**¿Qué significa que un arreglo se pase por referencia?**
Que la variable no guarda una copia de los elementos sino la dirección de la lista. Si una función recibe el arreglo y le hace `agregar`, el arreglo original cambia. Lo mismo pasa con `b = a;`: los dos nombres apuntan a la misma lista. Los números, textos y lógicos, en cambio, se copian.

**¿Por qué `[1, 2]` cabe en un `decimal[]` pero un `entero[]` no?**
Porque el literal todavía no tiene una variable propia: el compilador lo revisa contra el tipo donde se va a guardar y cada elemento entero se convierte a decimal. Un `entero[]` que ya existe sí es un arreglo con enteros guardados, y si se tratara como `decimal[]` se podrían meter decimales en él por otro nombre.

**¿Por qué lo hiciste en C?**
Porque C es el lenguaje que se pidió para el compilador. Además muestra mejor cómo funciona por dentro: yo mismo definí cómo se representan los tokens, los nodos del árbol, los valores y los arreglos, sin ayuda de clases ni listas del lenguaje.

**¿Cómo manejas los errores del parser en C, si no hay excepciones?**
Con `setjmp` y `longjmp`. Cuando una regla encuentra un error, guarda el mensaje y salta al último punto seguro (el bucle de `programa()` o de `bloque()`), que lo anota, se sincroniza hasta el siguiente `;` y sigue. Es el mismo modo pánico, pero hecho a mano.

**¿Qué agregaría después?**
Ciclos (`mientras`), que reutilizarían la misma idea de bloque y ámbito que ya uso para `si` y que permitirían recorrer los arreglos. También operadores lógicos (`y`, `o`, `no`) para combinar condiciones, y una fase de generación de código. Cada uno sería una regla nueva en la gramática, un nodo nuevo en el AST y un caso nuevo en el analizador semántico.

## Antes de presentar

- [ ] El link de GitHub abre en una ventana de incógnito.
- [ ] `make` compila sin advertencias y `make probar` termina con todo en ✔ en la computadora de la presentación.
- [ ] `./alex ejemplos/ok.alex`, `./alex ejemplos/funciones.alex`, `./alex ejemplos/condicionales.alex` y `./alex ejemplos/arreglos.alex` corren sin errores.
- [ ] La terminal de VS Code está abierta en la carpeta donde está `alex.c`.
