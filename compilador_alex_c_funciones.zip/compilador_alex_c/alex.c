/*
 * ALEX - Compilador (front-end) + intérprete, escrito en C
 * Estudiante: Alexis Viquez Terranova
 * Materia: Compiladores - UNADECA - Prof. William Martinez
 *
 * Fases:
 *   1. Análisis léxico      -> lista de tokens
 *   2. Análisis sintáctico  -> AST (árbol) + AST Table
 *   3. Análisis semántico   -> Tabla de Símbolos (con ámbitos) + verificación de tipos
 *   4. Ejecución            -> se interpreta el AST y se muestran los valores finales
 *
 * El lenguaje tiene variables, expresiones, condicionales, funciones y arreglos:
 *   - funciones predefinidas: mostrar, longitud, mayusculas, redondear, absoluto,
 *                             agregar (push), quitar (pop)
 *   - funciones propias:      funcion nombre(p: tipo, ...): tipo { ... retornar valor; }
 *   - condicionales:          si (condicion) { ... } sino { ... }   (con == != < > <= >=)
 *   - arreglos:               dato notas: decimal[] = [8.5, 9, 7.25];   notas[0]   notas[1] = 10;
 *
 * Compilar:   gcc -Wall -Wextra -O2 -o alex alex.c -lm      (o simplemente: make)
 * Uso:        ./alex programa.alex
 *             ./alex programa.alex --tokens     (muestra también la tabla de tokens)
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <setjmp.h>
#include <math.h>
#include <limits.h>
#include <errno.h>
#include <ctype.h>
#ifdef _WIN32
#include <windows.h>
#endif

/* =========================================================================
 * Utilidades: memoria, cadenas, UTF-8, vectores
 * (el programa es corto, así que la memoria no se libera: termina con el proceso)
 * ========================================================================= */
static void *xmalloc(size_t n) {
    void *p = calloc(1, n ? n : 1);
    if (!p) { fputs("Sin memoria\n", stderr); exit(2); }
    return p;
}

static void *xrealloc(void *p, size_t n) {
    p = realloc(p, n ? n : 1);
    if (!p) { fputs("Sin memoria\n", stderr); exit(2); }
    return p;
}

static char *sndup(const char *s, size_t n) {
    char *r = xmalloc(n + 1);
    memcpy(r, s, n);
    return r;
}

static char *sdup(const char *s) { return sndup(s, strlen(s)); }

static char *sf(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static char *sf(const char *fmt, ...) {
    va_list ap, ap2;
    va_start(ap, fmt);
    va_copy(ap2, ap);
    char medida[1];
    int n = vsnprintf(medida, sizeof medida, fmt, ap);
    va_end(ap);
    char *s = xmalloc((size_t)n + 1);
    vsnprintf(s, (size_t)n + 1, fmt, ap2);
    va_end(ap2);
    return s;
}

/* Vector de punteros que crece solo */
typedef struct { void **v; int n, cap; } Vec;

static void vec_push(Vec *a, void *x) {
    if (a->n == a->cap) {
        a->cap = a->cap ? a->cap * 2 : 8;
        a->v = xrealloc(a->v, (size_t)a->cap * sizeof(void *));
    }
    a->v[a->n++] = x;
}

/* UTF-8: las columnas y los anchos de tabla se cuentan en caracteres, no en bytes */
static int ulen_n(const char *s, size_t nbytes) {
    int c = 0;
    for (size_t i = 0; i < nbytes; i++)
        if (((unsigned char)s[i] & 0xC0) != 0x80) c++;
    return c;
}

static int ulen(const char *s) { return ulen_n(s, strlen(s)); }

static unsigned decodificar(const char *s, int *len) {
    unsigned char c = (unsigned char)s[0];
    if (c < 0x80) { *len = 1; return c; }
    if ((c >> 5) == 6 && (s[1] & 0xC0) == 0x80) {
        *len = 2;
        return ((unsigned)(c & 0x1F) << 6) | (unsigned)(s[1] & 0x3F);
    }
    if ((c >> 4) == 14 && (s[1] & 0xC0) == 0x80 && (s[2] & 0xC0) == 0x80) {
        *len = 3;
        return ((unsigned)(c & 0x0F) << 12) | ((unsigned)(s[1] & 0x3F) << 6) | (unsigned)(s[2] & 0x3F);
    }
    if ((c >> 3) == 30 && (s[1] & 0xC0) == 0x80 && (s[2] & 0xC0) == 0x80 && (s[3] & 0xC0) == 0x80) {
        *len = 4;
        return ((unsigned)(c & 0x07) << 18) | ((unsigned)(s[1] & 0x3F) << 12) |
               ((unsigned)(s[2] & 0x3F) << 6) | (unsigned)(s[3] & 0x3F);
    }
    *len = 1;
    return 0xFFFD;
}

static int codificar(unsigned cp, char *out) {
    if (cp < 0x80) { out[0] = (char)cp; return 1; }
    if (cp < 0x800) {
        out[0] = (char)(0xC0 | (cp >> 6));
        out[1] = (char)(0x80 | (cp & 0x3F));
        return 2;
    }
    if (cp < 0x10000) {
        out[0] = (char)(0xE0 | (cp >> 12));
        out[1] = (char)(0x80 | ((cp >> 6) & 0x3F));
        out[2] = (char)(0x80 | (cp & 0x3F));
        return 3;
    }
    out[0] = (char)(0xF0 | (cp >> 18));
    out[1] = (char)(0x80 | ((cp >> 12) & 0x3F));
    out[2] = (char)(0x80 | ((cp >> 6) & 0x3F));
    out[3] = (char)(0x80 | (cp & 0x3F));
    return 4;
}

/* Letras no ASCII que se aceptan en los nombres (á, é, ñ, ü, ...) */
static int es_letra_cp(unsigned cp) {
    return (cp >= 0xC0 && cp <= 0x24F && cp != 0xD7 && cp != 0xF7) ||
           cp == 0xAA || cp == 0xB5 || cp == 0xBA;
}

static char *strip_copia(const char *s) {
    while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') s++;
    size_t n = strlen(s);
    while (n > 0 && (s[n - 1] == ' ' || s[n - 1] == '\t' || s[n - 1] == '\r' || s[n - 1] == '\n')) n--;
    return sndup(s, n);
}

static void pr_pad(const char *s, int ancho) {
    fputs(s, stdout);
    for (int k = ulen(s); k < ancho; k++) putchar(' ');
}

/* =========================================================================
 * Definición del lenguaje
 *
 * Un tipo es un entero:  1..4 = entero, decimal, texto, logico
 *                        tipo | 8 = arreglo de ese tipo (entero[] ...)
 *                        8 solo   = arreglo vacío «[]» sin tipo todavía
 * Los valores >= 100 solo se usan en la tabla de funciones predefinidas.
 * ========================================================================= */
enum {
    T_NONE = 0, T_ENTERO = 1, T_DECIMAL = 2, T_TEXTO = 3, T_LOGICO = 4,
    T_ARR = 8,
    P_ANY = 100,       /* parámetro: cualquier valor                          */
    P_NUM,             /* parámetro: entero o decimal                         */
    P_TEXTO_O_ARR,     /* parámetro: texto o arreglo                          */
    P_ARR,             /* parámetro: cualquier arreglo                        */
    P_ELEM,            /* parámetro: del tipo de los elementos del 1er arreglo */
    R_ARG,             /* retorno: el mismo tipo que su argumento             */
    R_ELEM,            /* retorno: el tipo de los elementos del arreglo       */
    R_NUM2             /* retorno: entero si los dos argumentos son enteros, si no decimal */
};

static int es_arr(int t) { return t >= T_ARR && t < 16; }
static int base_de(int t) { return t & 7; }
static int arr_de(int t) { return t | T_ARR; }
static int es_num(int t) { return t == T_ENTERO || t == T_DECIMAL; }

static const char *tipo_nombre(int t) {
    static const char *n[] = {"?", "entero", "decimal", "texto", "logico"};
    if (es_arr(t)) return base_de(t) ? sf("%s[]", n[base_de(t)]) : "arreglo vacío";
    if (t >= 1 && t <= 4) return n[t];
    return "?";
}

static int tipo_desde_nombre(const char *s) {
    if (!strcmp(s, "entero")) return T_ENTERO;
    if (!strcmp(s, "decimal")) return T_DECIMAL;
    if (!strcmp(s, "texto")) return T_TEXTO;
    return T_LOGICO;
}

static int asignable(int destino, int origen) {
    if (destino == origen) return 1;
    if (destino == T_DECIMAL && origen == T_ENTERO) return 1;   /* entero cabe en decimal */
    if (es_arr(destino) && origen == T_ARR) return 1;           /* [] cabe en cualquier arreglo */
    return 0;
}

static int acepta(int esperado, int recibido) {
    switch (esperado) {
    case P_ANY: return 1;
    case P_NUM: return es_num(recibido);
    case P_TEXTO_O_ARR: return recibido == T_TEXTO || es_arr(recibido);
    case P_ARR: return es_arr(recibido);
    default: return asignable(esperado, recibido);
    }
}

static const char *desc_tipo(int t) {
    if (t == P_NUM) return "un número (entero o decimal)";
    if (t == P_TEXTO_O_ARR) return "un texto o un arreglo";
    if (t == P_ARR) return "un arreglo";
    return sf("de tipo %s", tipo_nombre(t));
}

static const char *plural(int n) { return sf("%d argumento%s", n, n == 1 ? "" : "s"); }

/* Funciones predefinidas de ALEX (la tabla completa: para agregar una, se agrega una fila
 * aquí y su comportamiento en llamar_predef()) */
typedef struct {
    const char *nombre;
    const char *pn[3];     /* nombres de los parámetros */
    int pt[3];             /* tipos de los parámetros   */
    int np;
    int ret;               /* tipo que devuelve; T_NONE = no devuelve valor */
    int variadica;         /* acepta más argumentos del último tipo */
} PredefDef;

static const PredefDef PREDEF[] = {
    {"mostrar",    {"valor"},             {P_ANY},            1, T_NONE,    1},
    {"longitud",   {"valor"},             {P_TEXTO_O_ARR},    1, T_ENTERO,  0},
    {"mayusculas", {"texto"},             {T_TEXTO},          1, T_TEXTO,   0},
    {"redondear",  {"numero"},            {T_DECIMAL},        1, T_ENTERO,  0},
    {"absoluto",   {"numero"},            {P_NUM},            1, R_ARG,     0},
    {"agregar",    {"arreglo", "valor"},  {P_ARR, P_ELEM},    2, T_NONE,    0},
    {"quitar",     {"arreglo"},           {P_ARR},            1, R_ELEM,    0},
    {"minimo",     {"a", "b"},            {P_NUM, P_NUM},     2, R_NUM2,    0},
    {"maximo",     {"a", "b"},            {P_NUM, P_NUM},     2, R_NUM2,    0},
    {"raiz",       {"numero"},            {P_NUM},            1, T_DECIMAL, 0},
    {"potencia",   {"base", "exponente"}, {P_NUM, P_NUM},     2, T_DECIMAL, 0},
    {"minusculas", {"texto"},             {T_TEXTO},          1, T_TEXTO,   0},
    {"invertir",   {"texto"},             {T_TEXTO},          1, T_TEXTO,   0},
    {"contiene",   {"texto", "buscado"},  {T_TEXTO, T_TEXTO}, 2, T_LOGICO,  0},
    {"subtexto",   {"texto", "inicio", "cantidad"}, {T_TEXTO, T_ENTERO, T_ENTERO}, 3, T_TEXTO, 0},
    {"aTexto",     {"valor"},             {P_ANY},            1, T_TEXTO,   0},
};
#define N_PREDEF ((int)(sizeof(PREDEF) / sizeof(PREDEF[0])))

static const PredefDef *buscar_predef(const char *nombre) {
    for (int i = 0; i < N_PREDEF; i++)
        if (!strcmp(PREDEF[i].nombre, nombre)) return &PREDEF[i];
    return NULL;
}

#define MAX_LLAMADAS 200   /* límite de llamadas anidadas (protege de recursión sin caso base) */

/* =========================================================================
 * Errores de las tres fases de compilación
 * ========================================================================= */
typedef struct {
    const char *fase;
    char *mensaje;
    int linea, col, orden;
} ErrorAlex;

static int contador_errores = 0;

static ErrorAlex *nuevo_error(const char *fase, char *msg, int linea, int col) {
    ErrorAlex *e = xmalloc(sizeof(ErrorAlex));
    e->fase = fase;
    e->mensaje = msg;
    e->linea = linea;
    e->col = col;
    e->orden = contador_errores++;
    return e;
}

/* =========================================================================
 * 1. ANALIZADOR LÉXICO
 * ========================================================================= */
typedef enum {
    TK_DATO, TK_FUNCION, TK_RETORNAR, TK_SI, TK_SINO, TK_TIPO, TK_VERDADERO, TK_FALSO,
    TK_IDENT, TK_ENTERO, TK_DECIMAL, TK_TEXTO,
    TK_DOSPUNTOS, TK_PUNTOCOMA, TK_IGUAL, TK_MAS, TK_MENOS, TK_POR, TK_DIV,
    TK_LPAR, TK_RPAR, TK_LLAVEIZQ, TK_LLAVEDER, TK_COMA, TK_MENOR, TK_MAYOR,
    TK_IGUALIGUAL, TK_DIFERENTE, TK_MENORIGUAL, TK_MAYORIGUAL,
    TK_LCORCHETE, TK_RCORCHETE, TK_EOF
} TokTipo;

static const char *TOK_NOMBRE[] = {
    "DATO", "FUNCION", "RETORNAR", "SI", "SINO", "TIPO", "VERDADERO", "FALSO",
    "IDENT", "ENTERO", "DECIMAL", "TEXTO",
    "DOSPUNTOS", "PUNTOCOMA", "IGUAL", "MAS", "MENOS", "POR", "DIV",
    "LPAR", "RPAR", "LLAVEIZQ", "LLAVEDER", "COMA", "MENOR", "MAYOR",
    "IGUALIGUAL", "DIFERENTE", "MENORIGUAL", "MAYORIGUAL",
    "LCORCHETE", "RCORCHETE", "EOF"
};

typedef struct { TokTipo tipo; char *valor; int linea, col, ancho; } Token;

static Token *tok_nuevo(TokTipo tipo, char *valor, int linea, int col, int ancho) {
    Token *t = xmalloc(sizeof(Token));
    t->tipo = tipo;
    t->valor = valor;
    t->linea = linea;
    t->col = col;
    t->ancho = ancho >= 0 ? ancho : ulen(valor);
    return t;
}

static int es_reservada_tok(TokTipo t) {
    return t == TK_DATO || t == TK_FUNCION || t == TK_RETORNAR || t == TK_SI || t == TK_SINO ||
           t == TK_TIPO || t == TK_VERDADERO || t == TK_FALSO;
}

static void analizar_lexico(const char *f, Vec *tokens, Vec *errs) {
    size_t n = strlen(f), i = 0, inicio_linea = 0;
    int linea = 1;

    while (i < n) {
        unsigned char c = (unsigned char)f[i];
        int col = ulen_n(f + inicio_linea, i - inicio_linea) + 1;
        int len = 1;
        unsigned cp = c < 0x80 ? c : decodificar(f + i, &len);

        if (c == '\n') {
            linea++;
            inicio_linea = i + 1;
            i++;
        } else if (c == ' ' || c == '\t' || c == '\r') {
            i++;
        } else if (c == '/' && i + 1 < n && f[i + 1] == '/') {          /* comentario de línea */
            while (i < n && f[i] != '\n') i++;
        } else if (isalpha(c) || c == '_' || (c >= 0x80 && es_letra_cp(cp))) {   /* identificador o reservada */
            size_t j = i;
            while (j < n) {
                unsigned char d = (unsigned char)f[j];
                if (isalnum(d) || d == '_') { j++; continue; }
                if (d >= 0x80) {
                    int l2;
                    unsigned c2 = decodificar(f + j, &l2);
                    if (es_letra_cp(c2)) { j += (size_t)l2; continue; }
                }
                break;
            }
            char *lex = sndup(f + i, j - i);
            TokTipo t = TK_IDENT;
            if (!strcmp(lex, "dato")) t = TK_DATO;
            else if (!strcmp(lex, "funcion")) t = TK_FUNCION;
            else if (!strcmp(lex, "retornar")) t = TK_RETORNAR;
            else if (!strcmp(lex, "si")) t = TK_SI;
            else if (!strcmp(lex, "sino")) t = TK_SINO;
            else if (!strcmp(lex, "entero") || !strcmp(lex, "decimal") ||
                     !strcmp(lex, "texto") || !strcmp(lex, "logico")) t = TK_TIPO;
            else if (!strcmp(lex, "verdadero")) t = TK_VERDADERO;
            else if (!strcmp(lex, "falso")) t = TK_FALSO;
            vec_push(tokens, tok_nuevo(t, lex, linea, col, -1));
            i = j;
        } else if (c >= '0' && c <= '9') {                              /* entero o decimal */
            size_t j = i;
            while (j < n && f[j] >= '0' && f[j] <= '9') j++;
            if (j < n && f[j] == '.') {
                size_t k = j + 1;
                if (k < n && f[k] >= '0' && f[k] <= '9') {
                    while (k < n && f[k] >= '0' && f[k] <= '9') k++;
                    vec_push(tokens, tok_nuevo(TK_DECIMAL, sndup(f + i, k - i), linea, col, -1));
                    i = k;
                } else {
                    vec_push(errs, nuevo_error("léxico",
                        sf("Número decimal mal formado «%.*s»: después del punto deben ir dígitos",
                           (int)(j + 1 - i), f + i), linea, col));
                    i = j + 1;
                }
            } else {
                char *lex = sndup(f + i, j - i);
                errno = 0;
                strtoll(lex, NULL, 10);
                if (errno == ERANGE) {
                    vec_push(errs, nuevo_error("léxico",
                        sf("El entero «%s» es demasiado grande (el máximo es 9223372036854775807)", lex),
                        linea, col));
                } else {
                    vec_push(tokens, tok_nuevo(TK_ENTERO, lex, linea, col, -1));
                }
                i = j;
            }
        } else if (c == '"') {                                          /* texto entre comillas dobles */
            size_t j = i + 1;
            while (j < n && f[j] != '"' && f[j] != '\n') j++;
            if (j >= n || f[j] == '\n') {
                vec_push(errs, nuevo_error("léxico",
                    sdup("Texto sin cerrar: falta la comilla doble de cierre"), linea, col));
                i = j;
            } else {
                vec_push(tokens, tok_nuevo(TK_TEXTO, sndup(f + i + 1, j - i - 1), linea, col,
                                           ulen_n(f + i, j - i + 1)));
                i = j + 1;
            }
        } else if (i + 1 < n && ((c == '=' && f[i + 1] == '=') || (c == '!' && f[i + 1] == '=') ||
                                 (c == '<' && f[i + 1] == '=') || (c == '>' && f[i + 1] == '='))) {
            TokTipo t = c == '=' ? TK_IGUALIGUAL : c == '!' ? TK_DIFERENTE :
                        c == '<' ? TK_MENORIGUAL : TK_MAYORIGUAL;
            vec_push(tokens, tok_nuevo(t, sndup(f + i, 2), linea, col, -1));
            i += 2;
        } else {
            TokTipo t = TK_EOF;
            switch (c) {
            case ':': t = TK_DOSPUNTOS; break;
            case ';': t = TK_PUNTOCOMA; break;
            case '=': t = TK_IGUAL; break;
            case '+': t = TK_MAS; break;
            case '-': t = TK_MENOS; break;
            case '*': t = TK_POR; break;
            case '/': t = TK_DIV; break;
            case '(': t = TK_LPAR; break;
            case ')': t = TK_RPAR; break;
            case '{': t = TK_LLAVEIZQ; break;
            case '}': t = TK_LLAVEDER; break;
            case ',': t = TK_COMA; break;
            case '<': t = TK_MENOR; break;
            case '>': t = TK_MAYOR; break;
            case '[': t = TK_LCORCHETE; break;
            case ']': t = TK_RCORCHETE; break;
            default: break;
            }
            if (t != TK_EOF) {
                vec_push(tokens, tok_nuevo(t, sndup(f + i, 1), linea, col, -1));
                i++;
            } else {
                vec_push(errs, nuevo_error("léxico",
                    sf("Carácter no válido en ALEX: «%.*s»", len, f + i), linea, col));
                i += (size_t)len;
            }
        }
    }
    vec_push(tokens, tok_nuevo(TK_EOF, sdup(""), linea,
                               ulen_n(f + inicio_linea, i - inicio_linea) + 1, 0));
}

/* =========================================================================
 * 2. ANALIZADOR SINTÁCTICO (descendente recursivo) -> AST
 *
 * Gramática de ALEX:
 *   programa    ::= { sentencia } EOF
 *   sentencia   ::= declaracion | asignacion | asig_indice | funcion | retorno | si | llamada ";"
 *   declaracion ::= "dato" IDENT ":" tipo [ "=" expresion ] ";"
 *   asignacion  ::= IDENT "=" expresion ";"
 *   asig_indice ::= IDENT "[" expresion "]" "=" expresion ";"
 *   funcion     ::= "funcion" IDENT "(" [ parametros ] ")" [ ":" tipo ] bloque  (solo al nivel principal)
 *   parametros  ::= IDENT ":" tipo { "," IDENT ":" tipo }
 *   tipo        ::= TIPO [ "[" "]" ]
 *   retorno     ::= "retornar" [ expresion ] ";"
 *   si          ::= "si" "(" expresion ")" bloque [ "sino" ( si | bloque ) ]
 *   bloque      ::= "{" { sentencia } "}"
 *   llamada     ::= IDENT "(" [ expresion { "," expresion } ] ")"
 *   expresion   ::= suma { ("==" | "!=" | "<" | ">" | "<=" | ">=") suma }
 *   suma        ::= termino { ("+" | "-") termino }
 *   termino     ::= factor  { ("*" | "/") factor }
 *   factor      ::= "-" factor | ENTERO | DECIMAL | TEXTO | "verdadero" | "falso"
 *                 | "[" [ expresion { "," expresion } ] "]"
 *                 | ( llamada | IDENT | "(" expresion ")" ) { "[" expresion "]" }
 * ========================================================================= */
enum {
    N_PROGRAMA, N_DECL, N_ASIG, N_ASIG_IDX, N_FUNCION, N_PARAM, N_BLOQUE, N_SI, N_RETORNO,
    N_LLAMADA, N_BINOP, N_UNARIO, N_LIT_ENT, N_LIT_DEC, N_LIT_TXT, N_LIT_LOG, N_VARIABLE,
    N_LISTA, N_INDICE
};

static const char *NODO_NOMBRE[] = {
    "Programa", "Declaracion", "Asignacion", "AsignacionIndice", "Funcion", "Parametro",
    "Bloque", "Si", "Retorno", "Llamada", "BinOp", "Unario", "LiteralEntero",
    "LiteralDecimal", "LiteralTexto", "LiteralLogico", "Variable", "LiteralArreglo", "Indice"
};

typedef struct Nodo {
    int k;                 /* clase de nodo (N_...)                         */
    char *valor;           /* texto que se muestra en el árbol (o NULL)      */
    Vec hijos;             /* Nodo*; en una función: parámetros y luego cuerpo */
    int linea;
    int tipo_dato;         /* lo llena el analizador semántico              */
    char *nombre;          /* variable, función o parámetro                 */
    int tipo_decl;         /* tipo declarado (Declaracion, Parametro)       */
    int tipo_ret;          /* tipo que devuelve (Funcion); T_NONE = ninguno */
    int np;                /* cantidad de parámetros (Funcion)              */
    int id, padre;         /* los llena la AST Table                        */
} Nodo;

#define H(x, i) ((Nodo *)(x)->hijos.v[i])
#define NH(x) ((x)->hijos.n)

static Nodo *nodo_nuevo(int k, const char *valor, int linea) {
    Nodo *n = xmalloc(sizeof(Nodo));
    n->k = k;
    n->valor = valor ? sdup(valor) : NULL;
    n->linea = linea;
    return n;
}

static void nodo_add(Nodo *n, Nodo *h) { vec_push(&n->hijos, h); }

static const char *simbolo(const Token *t) {
    if (t->tipo == TK_EOF) return "fin del archivo";
    if (t->tipo == TK_TEXTO) return sf("\"%s\"", t->valor);
    return t->valor;
}

typedef struct {
    Token **t;
    int p;
    Vec *errores;
    jmp_buf *jb;
    ErrorAlex *pend;
} Parser;

static Token *actual(Parser *P) { return P->t[P->p]; }
static Token *previo(Parser *P) { return P->p > 0 ? P->t[P->p - 1] : P->t[0]; }

static Token *avanzar(Parser *P) {
    Token *tok = P->t[P->p];
    if (tok->tipo != TK_EOF) P->p++;
    return tok;
}

static void perr_pos(Parser *P, const char *msg, int linea, int col) __attribute__((noreturn));
static void perr_pos(Parser *P, const char *msg, int linea, int col) {
    P->pend = nuevo_error("sintáctico", sdup(msg), linea, col);
    longjmp(*P->jb, 1);
}

static void perr(Parser *P, const char *msg, const Token *t) __attribute__((noreturn));
static void perr(Parser *P, const char *msg, const Token *t) { perr_pos(P, msg, t->linea, t->col); }

static Token *esperar(Parser *P, TokTipo tipo, const char *msg) {
    if (actual(P)->tipo == tipo) return avanzar(P);
    perr(P, msg, actual(P));
}

static void punto_y_coma(Parser *P) {
    if (actual(P)->tipo == TK_PUNTOCOMA) { avanzar(P); return; }
    Token *p = previo(P);
    perr_pos(P, "Falta «;» al final de la instrucción (toda instrucción termina con punto y coma)",
             p->linea, p->col + p->ancho);
}

static void sin_encadenar(Parser *P) {
    if (actual(P)->tipo == TK_IGUAL)
        perr(P, "No se pueden encadenar asignaciones (a = b = 3; no está permitido en ALEX)", actual(P));
}

/* Salta un bloque { ... } completo (con llaves anidadas). */
static void saltar_bloque(Parser *P) {
    int profundidad = 0;
    while (actual(P)->tipo != TK_EOF) {
        TokTipo t = avanzar(P)->tipo;
        if (t == TK_LLAVEIZQ) {
            profundidad++;
        } else if (t == TK_LLAVEDER) {
            profundidad--;
            if (profundidad == 0) return;
        }
    }
}

/* Recuperación de errores (modo pánico): salta hasta un punto seguro para seguir revisando
 * el resto del programa y poder reportar más de un error. */
static void sincronizar(Parser *P, int inicio) {
    while (actual(P)->tipo != TK_EOF) {
        TokTipo t = actual(P)->tipo;
        if (t == TK_PUNTOCOMA) { avanzar(P); return; }
        if ((t == TK_DATO || t == TK_FUNCION || t == TK_RETORNAR || t == TK_SI) && P->p > inicio) return;
        if (t == TK_LLAVEDER) {
            if (P->p == inicio) avanzar(P);          /* llave de cierre suelta: se descarta */
            return;
        }
        if (t == TK_LLAVEIZQ) { saltar_bloque(P); return; }
        avanzar(P);
    }
}

static Nodo *sentencia(Parser *P, int dentro);
static Nodo *expresion(Parser *P);
static Nodo *si(Parser *P);

/* tipo ::= TIPO [ "[" "]" ] */
static int parse_tipo(Parser *P, const char *msg_falta) {
    Token *tt = actual(P);
    if (tt->tipo != TK_TIPO) perr(P, msg_falta, tt);
    avanzar(P);
    int t = tipo_desde_nombre(tt->valor);
    if (actual(P)->tipo == TK_LCORCHETE) {
        avanzar(P);
        if (actual(P)->tipo != TK_RCORCHETE)
            perr(P, "Se esperaba «]» para cerrar el tipo arreglo (por ejemplo, entero[])", actual(P));
        avanzar(P);
        t = arr_de(t);
    }
    return t;
}

static Nodo *declaracion(Parser *P) {
    Token *tdato = avanzar(P);
    Token *t = actual(P);
    if (es_reservada_tok(t->tipo))
        perr(P, sf("«%s» es una palabra reservada y no puede usarse como nombre de variable", t->valor), t);
    if (t->tipo != TK_IDENT) perr(P, "Después de «dato» se esperaba el nombre de la variable", t);
    Token *nombre = avanzar(P);
    esperar(P, TK_DOSPUNTOS, "Se esperaba «:» después del nombre de la variable");
    int tipo = parse_tipo(P, "Se esperaba un tipo de dato (entero, decimal, texto o logico)");
    Nodo *n = nodo_nuevo(N_DECL, NULL, tdato->linea);
    n->valor = sf("%s: %s", nombre->valor, tipo_nombre(tipo));
    n->nombre = nombre->valor;
    n->tipo_decl = tipo;
    if (actual(P)->tipo == TK_IGUAL) {
        avanzar(P);
        nodo_add(n, expresion(P));
        sin_encadenar(P);
    }
    punto_y_coma(P);
    return n;
}

static Nodo *asignacion(Parser *P) {
    Token *nombre = avanzar(P);
    if (actual(P)->tipo == TK_LCORCHETE) {                    /* nombre[indice] = valor; */
        Token *corch = avanzar(P);
        Nodo *idx = expresion(P);
        esperar(P, TK_RCORCHETE, "Falta cerrar el corchete «]» del índice");
        if (actual(P)->tipo != TK_IGUAL)
            perr(P, sf("Después de «%s[...]» se esperaba «=» (asignación a un elemento del arreglo)",
                       nombre->valor), actual(P));
        avanzar(P);
        Nodo *n = nodo_nuevo(N_ASIG_IDX, nombre->valor, nombre->linea);
        n->nombre = nombre->valor;
        nodo_add(n, idx);
        nodo_add(n, expresion(P));
        (void)corch;
        sin_encadenar(P);
        punto_y_coma(P);
        return n;
    }
    if (actual(P)->tipo != TK_IGUAL)
        perr(P, sf("Después de «%s» se esperaba «=» (asignación)", nombre->valor), actual(P));
    avanzar(P);
    Nodo *n = nodo_nuevo(N_ASIG, nombre->valor, nombre->linea);
    nodo_add(n, expresion(P));
    n->nombre = nombre->valor;
    sin_encadenar(P);
    punto_y_coma(P);
    return n;
}

static Nodo *parametro(Parser *P) {
    Token *t = actual(P);
    if (es_reservada_tok(t->tipo))
        perr(P, sf("«%s» es una palabra reservada y no puede usarse como nombre de parámetro", t->valor), t);
    if (t->tipo != TK_IDENT) perr(P, "Se esperaba el nombre de un parámetro", t);
    Token *nombre = avanzar(P);
    esperar(P, TK_DOSPUNTOS,
            sf("Se esperaba «:» después del nombre del parámetro «%s»", nombre->valor));
    int tipo = parse_tipo(P, "Se esperaba el tipo del parámetro (entero, decimal, texto o logico)");
    Nodo *n = nodo_nuevo(N_PARAM, NULL, nombre->linea);
    n->valor = sf("%s: %s", nombre->valor, tipo_nombre(tipo));
    n->nombre = nombre->valor;
    n->tipo_decl = tipo;
    return n;
}

/* { sentencia* }  -> lista de sentencias. «que» describe el bloque para los mensajes. */
static Vec *bloque(Parser *P, const char *que) {
    Token *t = actual(P);
    if (t->tipo != TK_LLAVEIZQ) perr(P, sf("Se esperaba «{» para abrir %s", que), t);
    Token *llave = avanzar(P);
    Vec *sentencias = xmalloc(sizeof(Vec));
    while (actual(P)->tipo != TK_LLAVEDER && actual(P)->tipo != TK_EOF) {
        int inicio = P->p;
        jmp_buf jb;
        jmp_buf *prev = P->jb;
        P->jb = &jb;
        if (setjmp(jb) == 0) {
            vec_push(sentencias, sentencia(P, 1));
            P->jb = prev;
        } else {
            P->jb = prev;
            vec_push(P->errores, P->pend);
            sincronizar(P, inicio);
        }
    }
    if (actual(P)->tipo == TK_EOF)
        perr_pos(P, sf("Falta «}» para cerrar %s (abierto en la línea %d)", que, llave->linea),
                 llave->linea, llave->col);
    avanzar(P);
    return sentencias;
}

static Nodo *nodo_con_vec(int k, const char *valor, Vec *hijos, int linea) {
    Nodo *n = nodo_nuevo(k, valor, linea);
    for (int i = 0; i < hijos->n; i++) nodo_add(n, hijos->v[i]);
    return n;
}

static Nodo *funcion(Parser *P, int dentro) {
    Token *tf = actual(P);
    if (dentro)
        perr(P, "No se pueden definir funciones dentro de otra función ni dentro de un bloque "
                "(en ALEX las funciones se definen al nivel principal)", tf);
    avanzar(P);
    Token *t = actual(P);
    if (es_reservada_tok(t->tipo))
        perr(P, sf("«%s» es una palabra reservada y no puede usarse como nombre de función", t->valor), t);
    if (t->tipo != TK_IDENT) perr(P, "Después de «funcion» se esperaba el nombre de la función", t);
    Token *nombre = avanzar(P);
    esperar(P, TK_LPAR, sf("Se esperaba «(» después del nombre de la función «%s»", nombre->valor));
    Vec *params = xmalloc(sizeof(Vec));
    if (actual(P)->tipo != TK_RPAR) {
        while (1) {
            vec_push(params, parametro(P));
            if (actual(P)->tipo == TK_COMA) { avanzar(P); continue; }
            break;
        }
    }
    esperar(P, TK_RPAR, "Falta cerrar el paréntesis «)» de los parámetros");
    int tipo_ret = T_NONE;
    if (actual(P)->tipo == TK_DOSPUNTOS) {
        avanzar(P);
        tipo_ret = parse_tipo(P, "Se esperaba el tipo que devuelve la función (entero, decimal, texto o logico)");
    }
    Vec *cuerpo = bloque(P, sf("el cuerpo de la función «%s»", nombre->valor));

    char *firma = sf("%s(", nombre->valor);
    for (int i = 0; i < params->n; i++)
        firma = sf("%s%s%s", firma, i ? ", " : "", ((Nodo *)params->v[i])->valor);
    firma = sf("%s)", firma);

    Nodo *n = nodo_nuevo(N_FUNCION, firma, tf->linea);
    for (int i = 0; i < params->n; i++) nodo_add(n, params->v[i]);
    for (int i = 0; i < cuerpo->n; i++) nodo_add(n, cuerpo->v[i]);
    n->nombre = nombre->valor;
    n->np = params->n;
    n->tipo_ret = tipo_ret;
    return n;
}

static Nodo *si(Parser *P) {
    Token *ts = avanzar(P);
    esperar(P, TK_LPAR, "Se esperaba «(» después de «si»: la condición va entre paréntesis");
    Nodo *cond = expresion(P);
    esperar(P, TK_RPAR, "Falta cerrar el paréntesis «)» de la condición");
    Nodo *entonces = nodo_con_vec(N_BLOQUE, "entonces", bloque(P, "el bloque del «si»"), ts->linea);
    Nodo *n = nodo_nuevo(N_SI, NULL, ts->linea);
    nodo_add(n, cond);
    nodo_add(n, entonces);
    if (actual(P)->tipo == TK_SINO) {
        Token *tn = avanzar(P);
        if (actual(P)->tipo == TK_SI) {                       /* «sino si»: otro si dentro del sino */
            Nodo *b = nodo_nuevo(N_BLOQUE, "sino", tn->linea);
            nodo_add(b, si(P));
            nodo_add(n, b);
        } else {
            nodo_add(n, nodo_con_vec(N_BLOQUE, "sino", bloque(P, "el bloque del «sino»"), tn->linea));
        }
    }
    return n;
}

static Nodo *retorno(Parser *P) {
    Token *tr = avanzar(P);
    Nodo *n = nodo_nuevo(N_RETORNO, NULL, tr->linea);
    if (actual(P)->tipo != TK_PUNTOCOMA) {
        nodo_add(n, expresion(P));
        sin_encadenar(P);
    }
    punto_y_coma(P);
    return n;
}

static Nodo *llamada(Parser *P) {
    Token *nombre = avanzar(P);
    avanzar(P);                                               /* «(» */
    Nodo *n = nodo_nuevo(N_LLAMADA, nombre->valor, nombre->linea);
    n->nombre = nombre->valor;
    if (actual(P)->tipo != TK_RPAR) {
        while (1) {
            nodo_add(n, expresion(P));
            if (actual(P)->tipo == TK_COMA) { avanzar(P); continue; }
            break;
        }
    }
    if (actual(P)->tipo != TK_RPAR)
        perr(P, sf("Falta cerrar el paréntesis «)» de la llamada a «%s»", nombre->valor), actual(P));
    avanzar(P);
    return n;
}

static Nodo *sentencia(Parser *P, int dentro) {
    Token *t = actual(P);
    switch (t->tipo) {
    case TK_DATO: return declaracion(P);
    case TK_SI: return si(P);
    case TK_SINO: perr(P, "«sino» solo puede ir justo después del bloque de un «si»", t);
    case TK_FUNCION: return funcion(P, dentro);
    case TK_RETORNAR: return retorno(P);
    case TK_IDENT:
        if (P->t[P->p + 1]->tipo == TK_LPAR) {
            Nodo *n = llamada(P);
            punto_y_coma(P);
            return n;
        }
        return asignacion(P);
    case TK_TIPO:
    case TK_VERDADERO:
    case TK_FALSO:
        perr(P, sf("«%s» es una palabra reservada; una instrucción debe empezar con "
                   "«dato», «si», «funcion», «retornar» o el nombre de una variable o función", t->valor), t);
    default:
        break;
    }
    perr(P, sf("Instrucción inesperada «%s»: se esperaba «dato», «si», «funcion», "
               "«retornar» o el nombre de una variable o función", simbolo(t)), t);
}

static int es_comparador(TokTipo t) {
    return t == TK_IGUALIGUAL || t == TK_DIFERENTE || t == TK_MENOR || t == TK_MAYOR ||
           t == TK_MENORIGUAL || t == TK_MAYORIGUAL;
}

static Nodo *binop(Token *op, Nodo *izq, Nodo *der) {
    Nodo *n = nodo_nuevo(N_BINOP, op->valor, op->linea);
    nodo_add(n, izq);
    nodo_add(n, der);
    return n;
}

static Nodo *suma(Parser *P);
static Nodo *termino(Parser *P);
static Nodo *factor(Parser *P);

static Nodo *expresion(Parser *P) {
    Nodo *izq = suma(P);
    while (es_comparador(actual(P)->tipo)) {
        Token *op = avanzar(P);
        izq = binop(op, izq, suma(P));
    }
    return izq;
}

static Nodo *suma(Parser *P) {
    Nodo *izq = termino(P);
    while (actual(P)->tipo == TK_MAS || actual(P)->tipo == TK_MENOS) {
        Token *op = avanzar(P);
        izq = binop(op, izq, termino(P));
    }
    return izq;
}

static Nodo *termino(Parser *P) {
    Nodo *izq = factor(P);
    while (actual(P)->tipo == TK_POR || actual(P)->tipo == TK_DIV) {
        Token *op = avanzar(P);
        izq = binop(op, izq, factor(P));
    }
    return izq;
}

/* { "[" expresion "]" } después de una variable, una llamada o una expresión entre paréntesis */
static Nodo *postfijo(Parser *P, Nodo *base) {
    while (actual(P)->tipo == TK_LCORCHETE) {
        Token *tk = avanzar(P);
        Nodo *idx = expresion(P);
        esperar(P, TK_RCORCHETE, "Falta cerrar el corchete «]» del índice");
        Nodo *n = nodo_nuevo(N_INDICE, NULL, tk->linea);
        nodo_add(n, base);
        nodo_add(n, idx);
        base = n;
    }
    return base;
}

static Nodo *factor(Parser *P) {
    Token *t = actual(P);
    switch (t->tipo) {
    case TK_MENOS: {
        avanzar(P);
        if (actual(P)->tipo == TK_ENTERO || actual(P)->tipo == TK_DECIMAL) {   /* -15, -0.5 son literales */
            Token *num = avanzar(P);
            return nodo_nuevo(num->tipo == TK_ENTERO ? N_LIT_ENT : N_LIT_DEC,
                              sf("-%s", num->valor), t->linea);
        }
        Nodo *n = nodo_nuevo(N_UNARIO, "-", t->linea);
        nodo_add(n, factor(P));
        return n;
    }
    case TK_ENTERO: avanzar(P); return nodo_nuevo(N_LIT_ENT, t->valor, t->linea);
    case TK_DECIMAL: avanzar(P); return nodo_nuevo(N_LIT_DEC, t->valor, t->linea);
    case TK_TEXTO: avanzar(P); return nodo_nuevo(N_LIT_TXT, t->valor, t->linea);
    case TK_VERDADERO:
    case TK_FALSO: avanzar(P); return nodo_nuevo(N_LIT_LOG, t->valor, t->linea);
    case TK_IDENT:
        if (P->t[P->p + 1]->tipo == TK_LPAR) return postfijo(P, llamada(P));
        avanzar(P);
        return postfijo(P, nodo_nuevo(N_VARIABLE, t->valor, t->linea));
    case TK_LPAR: {
        avanzar(P);
        Nodo *e = expresion(P);
        esperar(P, TK_RPAR, "Falta cerrar el paréntesis «)»");
        return postfijo(P, e);
    }
    case TK_LCORCHETE: {                                      /* literal de arreglo: [1, 2, 3] */
        avanzar(P);
        Nodo *l = nodo_nuevo(N_LISTA, NULL, t->linea);
        if (actual(P)->tipo != TK_RCORCHETE) {
            while (1) {
                nodo_add(l, expresion(P));
                if (actual(P)->tipo == TK_COMA) { avanzar(P); continue; }
                break;
            }
        }
        if (actual(P)->tipo != TK_RCORCHETE)
            perr(P, "Falta cerrar el corchete «]» del arreglo", actual(P));
        avanzar(P);
        return l;
    }
    default:
        break;
    }
    perr(P, sf("Se esperaba un valor o expresión, pero se encontró «%s»", simbolo(t)), t);
}

static Nodo *programa(Parser *P) {
    Nodo *raiz = nodo_nuevo(N_PROGRAMA, NULL, 1);
    while (actual(P)->tipo != TK_EOF) {
        int inicio = P->p;
        jmp_buf jb;
        jmp_buf *prev = P->jb;
        P->jb = &jb;
        if (setjmp(jb) == 0) {
            nodo_add(raiz, sentencia(P, 0));
            P->jb = prev;
        } else {
            P->jb = prev;
            vec_push(P->errores, P->pend);
            sincronizar(P, inicio);
        }
    }
    return raiz;
}

/* =========================================================================
 * 3. ANALIZADOR SEMÁNTICO + TABLA DE SÍMBOLOS (con ámbitos)
 *
 * Ámbitos: hay un ámbito «global»; cada función tiene el suyo y cada bloque de
 * un «si» o «sino» abre un ámbito anidado. Un bloque ve las variables de los
 * bloques que lo rodean. Una función solo ve sus parámetros y sus variables
 * locales (no ve las globales).
 * ========================================================================= */
typedef struct {
    char *nombre;
    int tipo;
    int linea;
    char *ambito;
    const char *clase;            /* variable | parámetro */
    int con_valor, asignaciones, lecturas;
    char *valor_inicial, *valor_final;
} Simbolo;

typedef struct { char *etiqueta; Vec syms; } Ambito;

typedef struct { char *nombre; int tipo; } ParamInfo;

typedef struct {
    char *nombre;
    ParamInfo *params;
    int np;
    int ret;
    int linea;
    int predefinida, variadica, llamadas;
} InfoFuncion;

typedef struct {
    Vec pila;                     /* ámbitos activos (Ambito*)              */
    Ambito *globales;
    Vec simbolos;                 /* todos, en orden de declaración         */
    Vec funciones;                /* InfoFuncion* definidas por el programador */
    Vec predef;                   /* InfoFuncion* predefinidas (se crean al usarlas) */
    InfoFuncion *funcion_actual;
    Vec errores;
} Semantico;

static void sem_err(Semantico *S, char *msg, int linea) {
    vec_push(&S->errores, nuevo_error("semántico", msg, linea, 0));
}

static Ambito *ambito_nuevo(const char *etiqueta) {
    Ambito *a = xmalloc(sizeof(Ambito));
    a->etiqueta = sdup(etiqueta);
    return a;
}

static Simbolo *ambito_buscar(Ambito *a, const char *nombre) {
    for (int i = 0; i < a->syms.n; i++)
        if (!strcmp(((Simbolo *)a->syms.v[i])->nombre, nombre)) return a->syms.v[i];
    return NULL;
}

static InfoFuncion *buscar_funcion_def(Semantico *S, const char *nombre) {
    for (int i = 0; i < S->funciones.n; i++)
        if (!strcmp(((InfoFuncion *)S->funciones.v[i])->nombre, nombre)) return S->funciones.v[i];
    return NULL;
}

static InfoFuncion *info_predef(Semantico *S, const PredefDef *d) {
    for (int i = 0; i < S->predef.n; i++)
        if (!strcmp(((InfoFuncion *)S->predef.v[i])->nombre, d->nombre)) return S->predef.v[i];
    InfoFuncion *f = xmalloc(sizeof(InfoFuncion));
    f->nombre = sdup(d->nombre);
    f->np = d->np;
    f->params = xmalloc(sizeof(ParamInfo) * (size_t)d->np);
    for (int i = 0; i < d->np; i++) {
        f->params[i].nombre = sdup(d->pn[i]);
        f->params[i].tipo = d->pt[i];
    }
    f->ret = d->ret;
    f->predefinida = 1;
    f->variadica = d->variadica;
    vec_push(&S->predef, f);
    return f;
}

static int es_funcion(Semantico *S, const char *nombre) {
    return buscar_predef(nombre) != NULL || buscar_funcion_def(S, nombre) != NULL;
}

/* Busca una variable desde el ámbito más interno hacia afuera. */
static Simbolo *buscar(Semantico *S, const char *nombre) {
    for (int i = S->pila.n - 1; i >= 0; i--) {
        Simbolo *s = ambito_buscar(S->pila.v[i], nombre);
        if (s) return s;
    }
    return NULL;
}

static Ambito *ambito_actual(Semantico *S) { return S->pila.v[S->pila.n - 1]; }

static char *msg_no_declarada(Semantico *S, const char *nombre, int asignando) {
    char *msg = sf("La variable «%s» no está declarada", nombre);
    if (S->funcion_actual && ambito_buscar(S->globales, nombre))
        msg = sf("%s en esta función (una función no ve las variables globales; recíbela como parámetro)", msg);
    else if (asignando)
        msg = sf("%s (hay que declararla antes con «dato»)", msg);
    return msg;
}

static int tipo_expr_esp(Semantico *S, Nodo *n, int esperado);
static int sem_sentencia(Semantico *S, Nodo *s);

static int tipo_expr(Semantico *S, Nodo *n) { return tipo_expr_esp(S, n, T_NONE); }

static void compatible(Semantico *S, int destino, int origen, const char *nombre, int linea) {
    if (asignable(destino, origen)) return;
    if (destino == T_ENTERO && origen == T_DECIMAL)
        sem_err(S, sf("No se puede guardar un decimal en «%s», que es de tipo entero", nombre), linea);
    else
        sem_err(S, sf("Tipos incompatibles: «%s» es de tipo %s y se esperaba un valor %s, "
                      "pero se recibió %s", nombre, tipo_nombre(destino), tipo_nombre(destino),
                      tipo_nombre(origen)), linea);
}

/* Revisa que un índice sea entero y que lo indexado sea un arreglo. Devuelve el tipo del elemento. */
static int indice_ok(Semantico *S, int tb, int ti, int linea, const char *que) {
    int res = T_NONE;
    if (tb != T_NONE) {
        if (!es_arr(tb))
            sem_err(S, sf("Solo se pueden usar corchetes con arreglos, y %s es de tipo %s", que,
                          tipo_nombre(tb)), linea);
        else if (base_de(tb))
            res = base_de(tb);
    }
    if (ti != T_NONE && ti != T_ENTERO)
        sem_err(S, sf("El índice de un arreglo debe ser entero, pero es %s", tipo_nombre(ti)), linea);
    return res;
}

static int sem_llamada(Semantico *S, Nodo *n, int en_expresion) {
    const char *nombre = n->nombre;
    const PredefDef *pd = buscar_predef(nombre);
    InfoFuncion *info = pd ? info_predef(S, pd) : buscar_funcion_def(S, nombre);

    int na = NH(n);
    int *tipos = xmalloc(sizeof(int) * (size_t)(na ? na : 1));
    for (int i = 0; i < na; i++) {
        int esp = T_NONE;       /* un literal [..] toma el tipo del parámetro que lo recibe */
        if (info && !info->predefinida && i < info->np && es_arr(info->params[i].tipo))
            esp = info->params[i].tipo;
        tipos[i] = tipo_expr_esp(S, H(n, i), esp);
    }

    if (!info) {
        if (buscar(S, nombre))
            sem_err(S, sf("«%s» es una variable, no una función", nombre), n->linea);
        else
            sem_err(S, sf("La función «%s» no está definida (hay que definirla antes de llamarla)", nombre),
                    n->linea);
        return T_NONE;
    }
    info->llamadas++;

    int esperados = info->np, recibidos = na;
    if (info->variadica && recibidos < esperados) {
        sem_err(S, sf("La función «%s» necesita al menos %s y se le pasaron %d", nombre,
                      plural(esperados), recibidos), n->linea);
    } else if (!info->variadica && recibidos != esperados) {
        sem_err(S, sf("La función «%s» espera %s y se le pasaron %d", nombre, plural(esperados),
                      recibidos), n->linea);
    } else {
        for (int i = 0; i < na; i++) {
            int ptipo = info->params[i < esperados ? i : esperados - 1].tipo;
            int rec = tipos[i];
            if (ptipo == P_ELEM) {          /* agregar(arreglo, valor): el valor es del tipo de los elementos */
                int t0 = tipos[0];
                ptipo = (t0 != T_NONE && es_arr(t0) && base_de(t0)) ? base_de(t0) : P_ANY;
            }
            if (rec != T_NONE && !acepta(ptipo, rec))
                sem_err(S, sf("El argumento %d de «%s» debe ser %s, pero se recibió %s", i + 1, nombre,
                              desc_tipo(ptipo), tipo_nombre(rec)), n->linea);
        }
    }

    if (info->ret == T_NONE) {
        if (en_expresion)
            sem_err(S, sf("La función «%s» no devuelve ningún valor: no se puede usar dentro de una "
                          "expresión", nombre), n->linea);
        n->tipo_dato = T_NONE;
        return T_NONE;
    }
    int ret = info->ret;
    if (ret == R_ARG)                       /* absoluto: devuelve el tipo de su argumento */
        ret = (na > 0 && es_num(tipos[0])) ? tipos[0] : T_NONE;
    else if (ret == R_NUM2)                 /* minimo / maximo: entero si ambos son enteros */
        ret = (na >= 2 && es_num(tipos[0]) && es_num(tipos[1]))
                  ? ((tipos[0] == T_ENTERO && tipos[1] == T_ENTERO) ? T_ENTERO : T_DECIMAL) : T_NONE;
    else if (ret == R_ELEM)                 /* quitar: devuelve el tipo de los elementos */
        ret = (na > 0 && es_arr(tipos[0]) && base_de(tipos[0])) ? base_de(tipos[0]) : T_NONE;
    n->tipo_dato = ret;
    return ret;
}

static int sem_tipo(Semantico *S, Nodo *n, int esp) {
    switch (n->k) {
    case N_LIT_ENT: return T_ENTERO;
    case N_LIT_DEC: return T_DECIMAL;
    case N_LIT_TXT: return T_TEXTO;
    case N_LIT_LOG: return T_LOGICO;
    case N_VARIABLE: {
        Simbolo *s = buscar(S, n->valor);
        if (!s) {
            if (es_funcion(S, n->valor))
                sem_err(S, sf("«%s» es una función; para usarla escribe «%s(...)»", n->valor, n->valor), n->linea);
            else
                sem_err(S, msg_no_declarada(S, n->valor, 0), n->linea);
            return T_NONE;
        }
        s->lecturas++;
        return s->tipo;
    }
    case N_LLAMADA: return sem_llamada(S, n, 1);
    case N_UNARIO: {
        int t = tipo_expr(S, H(n, 0));
        if (t == T_NONE) return T_NONE;
        if (es_num(t)) return t;
        sem_err(S, sf("El signo «-» solo se aplica a entero o decimal, no a %s", tipo_nombre(t)), n->linea);
        return T_NONE;
    }
    case N_LISTA: {
        int ne = NH(n);
        int *te = xmalloc(sizeof(int) * (size_t)(ne ? ne : 1));
        for (int i = 0; i < ne; i++) {
            te[i] = tipo_expr(S, H(n, i));
            if (es_arr(te[i])) {
                sem_err(S, sdup("Un arreglo no puede contener otros arreglos"), H(n, i)->linea);
                return T_NONE;
            }
        }
        if (es_arr(esp) && base_de(esp)) {          /* se sabe qué tipo de arreglo se espera */
            int b = base_de(esp);
            for (int i = 0; i < ne; i++) {
                if (te[i] == T_NONE || asignable(b, te[i])) continue;
                if (b == T_ENTERO && te[i] == T_DECIMAL)
                    sem_err(S, sf("El elemento %d del arreglo es decimal y no cabe en un arreglo de "
                                  "entero", i + 1), H(n, i)->linea);
                else
                    sem_err(S, sf("El elemento %d del arreglo debe ser %s, pero es %s", i + 1,
                                  tipo_nombre(b), tipo_nombre(te[i])), H(n, i)->linea);
            }
            return esp;
        }
        if (ne == 0) return T_ARR;                  /* arreglo vacío: toma el tipo de donde se guarde */
        int base = T_NONE, hay_decimal = 0, todos_num = 1, mismo = 1;
        for (int i = 0; i < ne; i++) {
            if (te[i] == T_NONE) return T_NONE;     /* ya hubo un error dentro del elemento */
            if (!es_num(te[i])) todos_num = 0;
            if (te[i] == T_DECIMAL) hay_decimal = 1;
            if (te[i] != te[0]) mismo = 0;
        }
        if (todos_num) base = hay_decimal ? T_DECIMAL : T_ENTERO;
        else if (mismo) base = te[0];
        else {
            sem_err(S, sf("Los elementos del arreglo deben ser todos del mismo tipo (hay %s y %s)",
                          tipo_nombre(te[0]), tipo_nombre(te[1] != te[0] ? te[1] : te[ne - 1])), n->linea);
            return T_NONE;
        }
        return arr_de(base);
    }
    case N_INDICE: {
        int tb = tipo_expr(S, H(n, 0));
        int ti = tipo_expr(S, H(n, 1));
        const char *que = H(n, 0)->k == N_VARIABLE ? sf("«%s»", H(n, 0)->valor) : "esta expresión";
        return indice_ok(S, tb, ti, n->linea, que);
    }
    case N_BINOP: {
        int ti = tipo_expr(S, H(n, 0));
        int td = tipo_expr(S, H(n, 1));
        if (ti == T_NONE || td == T_NONE) return T_NONE;
        const char *op = n->valor;
        int num = es_num(ti) && es_num(td);
        if (!strcmp(op, "<") || !strcmp(op, ">") || !strcmp(op, "<=") || !strcmp(op, ">=")) {
            if (num) return T_LOGICO;
            sem_err(S, sf("El operador «%s» solo compara números (entero o decimal), no %s con %s", op,
                          tipo_nombre(ti), tipo_nombre(td)), n->linea);
            return T_NONE;
        }
        if (!strcmp(op, "==") || !strcmp(op, "!=")) {
            if (es_arr(ti) || es_arr(td)) {
                sem_err(S, sf("No se pueden comparar arreglos con «%s» (compara sus elementos uno por uno)",
                              op), n->linea);
                return T_NONE;
            }
            if (num || ti == td) return T_LOGICO;
            sem_err(S, sf("No se puede comparar %s con %s usando «%s»", tipo_nombre(ti), tipo_nombre(td), op),
                    n->linea);
            return T_NONE;
        }
        if (num) return (ti == T_ENTERO && td == T_ENTERO && op[0] != '/') ? T_ENTERO : T_DECIMAL;
        if (op[0] == '+' && ti == T_TEXTO && td == T_TEXTO) return T_TEXTO;      /* concatenación */
        sem_err(S, sf("El operador «%s» no se puede aplicar a %s y %s", op, tipo_nombre(ti), tipo_nombre(td)),
                n->linea);
        return T_NONE;
    }
    default:
        return T_NONE;
    }
}

/* «esperado»: tipo de arreglo que se espera (para que [1, 2] pueda guardarse en un decimal[]) */
static int tipo_expr_esp(Semantico *S, Nodo *n, int esperado) {
    int t = sem_tipo(S, n, esperado);
    n->tipo_dato = t;
    return t;
}

static void sem_declaracion(Semantico *S, Nodo *n) {
    int te = NH(n) ? tipo_expr_esp(S, H(n, 0), es_arr(n->tipo_decl) ? n->tipo_decl : T_NONE) : T_NONE;
    Ambito *actual_ = ambito_actual(S);
    if (es_funcion(S, n->nombre)) {
        sem_err(S, sf("«%s» ya es el nombre de una función y no puede usarse como variable", n->nombre),
                n->linea);
    } else if (ambito_buscar(actual_, n->nombre)) {
        sem_err(S, sf("La variable «%s» ya fue declarada en la línea %d", n->nombre,
                      ambito_buscar(actual_, n->nombre)->linea), n->linea);
    } else {
        Simbolo *s = xmalloc(sizeof(Simbolo));
        s->nombre = n->nombre;
        s->tipo = n->tipo_decl;
        s->linea = n->linea;
        s->ambito = actual_->etiqueta;
        s->clase = "variable";
        s->con_valor = NH(n) > 0;
        vec_push(&actual_->syms, s);
        vec_push(&S->simbolos, s);
    }
    n->tipo_dato = n->tipo_decl;
    if (te != T_NONE) compatible(S, n->tipo_decl, te, n->nombre, n->linea);
}

static void sem_asignacion(Semantico *S, Nodo *n) {
    int te = tipo_expr(S, H(n, 0));
    Simbolo *s = buscar(S, n->nombre);
    if (!s) {
        if (es_funcion(S, n->nombre))
            sem_err(S, sf("«%s» es una función, no una variable: no se le puede asignar un valor", n->nombre),
                    n->linea);
        else
            sem_err(S, msg_no_declarada(S, n->nombre, 1), n->linea);
        return;
    }
    s->asignaciones++;
    n->tipo_dato = s->tipo;
    if (es_arr(s->tipo) && H(n, 0)->k == N_LISTA)       /* volver a evaluar el literal con el tipo esperado */
        te = tipo_expr_esp(S, H(n, 0), s->tipo);
    if (te != T_NONE) compatible(S, s->tipo, te, n->nombre, n->linea);
}

static void sem_asig_indice(Semantico *S, Nodo *n) {
    int ti = tipo_expr(S, H(n, 0));
    int te = tipo_expr(S, H(n, 1));
    Simbolo *s = buscar(S, n->nombre);
    if (!s) {
        if (es_funcion(S, n->nombre))
            sem_err(S, sf("«%s» es una función, no un arreglo", n->nombre), n->linea);
        else
            sem_err(S, msg_no_declarada(S, n->nombre, 1), n->linea);
        return;
    }
    s->asignaciones++;
    int et = indice_ok(S, s->tipo, ti, n->linea, sf("«%s»", n->nombre));
    n->tipo_dato = et;
    if (et != T_NONE && te != T_NONE)
        compatible(S, et, te, sf("%s[...]", n->nombre), n->linea);
}

/* Analiza una lista de sentencias. Devuelve 1 si todos sus caminos retornan. */
static int sem_lista(Semantico *S, Nodo **sentencias, int n) {
    int retorna = 0, linea_ret = 0, avisado = 0;
    for (int i = 0; i < n; i++) {
        Nodo *st = sentencias[i];
        if (retorna && !avisado) {
            sem_err(S, sf("Código inalcanzable: antes de esta instrucción siempre se ejecuta un «retornar» "
                          "(línea %d)", linea_ret), st->linea);
            avisado = 1;
        }
        if (sem_sentencia(S, st) && !retorna) {
            retorna = 1;
            linea_ret = st->linea;
        }
    }
    return retorna;
}

/* Abre un ámbito anidado para un bloque de «si» o «sino». */
static int sem_bloque(Semantico *S, Nodo *nodo, const char *etiqueta) {
    vec_push(&S->pila, ambito_nuevo(sf("%s/%s", ambito_actual(S)->etiqueta, etiqueta)));
    int retorna = sem_lista(S, (Nodo **)nodo->hijos.v, NH(nodo));
    S->pila.n--;
    return retorna;
}

static int sem_si(Semantico *S, Nodo *n) {
    int tc = tipo_expr(S, H(n, 0));
    if (tc != T_NONE && tc != T_LOGICO)
        sem_err(S, sf("La condición del «si» debe ser logico, pero es %s "
                      "(usa una comparación, por ejemplo «edad >= 18»)", tipo_nombre(tc)), n->linea);
    int retorna_si = sem_bloque(S, H(n, 1), sf("si@%d", n->linea));
    if (NH(n) == 3) {
        int retorna_sino = sem_bloque(S, H(n, 2), sf("sino@%d", H(n, 2)->linea));
        return retorna_si && retorna_sino;
    }
    return 0;
}

static void sem_funcion(Semantico *S, Nodo *n) {
    const char *nombre = n->nombre;
    InfoFuncion *info = xmalloc(sizeof(InfoFuncion));
    info->nombre = n->nombre;
    info->np = n->np;
    info->params = xmalloc(sizeof(ParamInfo) * (size_t)(n->np ? n->np : 1));
    for (int i = 0; i < n->np; i++) {
        info->params[i].nombre = H(n, i)->nombre;
        info->params[i].tipo = H(n, i)->tipo_decl;
    }
    info->ret = n->tipo_ret;
    info->linea = n->linea;

    int valida = 1;
    if (buscar_predef(nombre)) {
        sem_err(S, sf("«%s» es una función predefinida de ALEX y no se puede redefinir", nombre), n->linea);
        valida = 0;
    } else if (buscar_funcion_def(S, nombre)) {
        sem_err(S, sf("La función «%s» ya fue definida en la línea %d", nombre,
                      buscar_funcion_def(S, nombre)->linea), n->linea);
        valida = 0;
    } else if (ambito_buscar(S->globales, nombre)) {
        sem_err(S, sf("«%s» ya es el nombre de una variable (línea %d)", nombre,
                      ambito_buscar(S->globales, nombre)->linea), n->linea);
        valida = 0;
    }
    if (valida) vec_push(&S->funciones, info);      /* se registra antes del cuerpo (permite recursión) */
    n->tipo_dato = n->tipo_ret;

    Vec pila_anterior = S->pila;
    InfoFuncion *func_anterior = S->funcion_actual;
    memset(&S->pila, 0, sizeof(Vec));
    Ambito *vars_f = ambito_nuevo(nombre);            /* la función solo ve su propio ámbito */
    vec_push(&S->pila, vars_f);
    S->funcion_actual = info;

    for (int i = 0; i < n->np; i++) {                 /* parámetros = primeras variables del ámbito */
        Nodo *p = H(n, i);
        p->tipo_dato = p->tipo_decl;
        if (ambito_buscar(vars_f, p->nombre)) {
            sem_err(S, sf("El parámetro «%s» está repetido en la función «%s»", p->nombre, nombre), p->linea);
        } else if (es_funcion(S, p->nombre)) {
            sem_err(S, sf("El parámetro «%s» no puede llamarse igual que una función", p->nombre), p->linea);
        } else {
            Simbolo *s = xmalloc(sizeof(Simbolo));
            s->nombre = p->nombre;
            s->tipo = p->tipo_decl;
            s->linea = p->linea;
            s->ambito = vars_f->etiqueta;
            s->clase = "parámetro";
            s->con_valor = 1;
            vec_push(&vars_f->syms, s);
            vec_push(&S->simbolos, s);
        }
    }

    int retorna = sem_lista(S, (Nodo **)n->hijos.v + n->np, NH(n) - n->np);
    if (n->tipo_ret != T_NONE && !retorna)
        sem_err(S, sf("La función «%s» debe devolver un valor %s, pero no tiene «retornar» en todos sus "
                      "caminos", nombre, tipo_nombre(n->tipo_ret)), n->linea);
    S->pila = pila_anterior;
    S->funcion_actual = func_anterior;
}

static void sem_retorno(Semantico *S, Nodo *n) {
    InfoFuncion *f = S->funcion_actual;
    int esp = (f && es_arr(f->ret)) ? f->ret : T_NONE;
    int te = NH(n) ? tipo_expr_esp(S, H(n, 0), esp) : T_NONE;
    n->tipo_dato = te;
    if (!f) {
        sem_err(S, sdup("«retornar» solo se puede usar dentro de una función"), n->linea);
        return;
    }
    if (NH(n)) {
        if (f->ret == T_NONE) {
            sem_err(S, sf("La función «%s» no declara qué tipo devuelve, así que no puede devolver un valor "
                          "(agrega «: tipo» después de los parámetros)", f->nombre), n->linea);
        } else if (te != T_NONE && !asignable(f->ret, te)) {
            if (f->ret == T_ENTERO && te == T_DECIMAL)
                sem_err(S, sf("La función «%s» devuelve entero, pero «retornar» entrega un decimal "
                              "(un decimal no cabe en un entero)", f->nombre), n->linea);
            else
                sem_err(S, sf("La función «%s» devuelve %s, pero «retornar» entrega %s", f->nombre,
                              tipo_nombre(f->ret), tipo_nombre(te)), n->linea);
        }
    } else if (f->ret != T_NONE) {
        sem_err(S, sf("La función «%s» debe devolver un valor %s: falta el valor después de «retornar»",
                      f->nombre, tipo_nombre(f->ret)), n->linea);
    }
}

/* Analiza una sentencia. Devuelve 1 si siempre termina en un «retornar». */
static int sem_sentencia(Semantico *S, Nodo *s) {
    switch (s->k) {
    case N_DECL: sem_declaracion(S, s); break;
    case N_ASIG: sem_asignacion(S, s); break;
    case N_ASIG_IDX: sem_asig_indice(S, s); break;
    case N_FUNCION: sem_funcion(S, s); break;
    case N_RETORNO: sem_retorno(S, s); return 1;
    case N_LLAMADA: s->tipo_dato = sem_llamada(S, s, 0); break;
    case N_SI: return sem_si(S, s);
    default: break;
    }
    return 0;
}

/* =========================================================================
 * 4. EJECUCIÓN (intérprete del AST)
 * ========================================================================= */
typedef struct Lista Lista;
enum { V_NONE, V_ENTERO, V_DECIMAL, V_TEXTO, V_LOGICO, V_LISTA };

typedef struct {
    int tag;
    union { long long i; double d; const char *s; Lista *l; } u;
} Valor;

struct Lista { int elem; Valor *v; int n, cap; };     /* los arreglos se pasan por referencia */

static Valor v_ent(long long i) { Valor v; v.tag = V_ENTERO; v.u.i = i; return v; }
static Valor v_dec(double d) { Valor v; v.tag = V_DECIMAL; v.u.d = d; return v; }
static Valor v_txt(const char *s) { Valor v; v.tag = V_TEXTO; v.u.s = s; return v; }
static Valor v_log(int b) { Valor v; v.tag = V_LOGICO; v.u.i = b != 0; return v; }
static Valor v_lista(Lista *l) { Valor v; v.tag = V_LISTA; v.u.l = l; return v; }
static Valor v_none(void) { Valor v; memset(&v, 0, sizeof v); return v; }

static double a_dec(Valor v) { return v.tag == V_DECIMAL ? v.u.d : (double)v.u.i; }

static void lista_push(Lista *l, Valor v) {
    if (l->n == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 4;
        l->v = xrealloc(l->v, sizeof(Valor) * (size_t)l->cap);
    }
    l->v[l->n++] = v;
}

typedef struct { char *nombre; Valor v; } Var;
typedef struct Entorno { Vec vars; struct Entorno *padre; } Entorno;

/* Variables en tiempo de ejecución. Cada bloque y cada llamada a una función
 * crea uno nuevo; un bloque puede ver el entorno que lo rodea (padre). */
static Entorno *entorno_nuevo(Entorno *padre) {
    Entorno *e = xmalloc(sizeof(Entorno));
    e->padre = padre;
    return e;
}

static Var *entorno_buscar_aqui(Entorno *e, const char *nombre) {
    for (int i = 0; i < e->vars.n; i++)
        if (!strcmp(((Var *)e->vars.v[i])->nombre, nombre)) return e->vars.v[i];
    return NULL;
}

static void entorno_declarar(Entorno *e, const char *nombre, Valor v) {
    Var *x = entorno_buscar_aqui(e, nombre);
    if (!x) {
        x = xmalloc(sizeof(Var));
        x->nombre = sdup(nombre);
        vec_push(&e->vars, x);
    }
    x->v = v;
}

static Var *entorno_obtener(Entorno *e, const char *nombre) {
    for (; e; e = e->padre) {
        Var *x = entorno_buscar_aqui(e, nombre);
        if (x) return x;
    }
    return NULL;
}

typedef struct { int tipo; int linea; char *texto; } Evento;     /* tipo: 0 = traza, 1 = salida */

typedef struct {
    Vec funciones;              /* Nodo* de las funciones ya definidas        */
    Vec eventos;                /* Evento*                                    */
    Vec salida;                 /* lo que imprimió «mostrar»                  */
    int profundidad;            /* llamadas a funciones que están en curso    */
    int retornando;             /* 1 mientras se sale de una función          */
    Valor valor_ret;
    int rama;                   /* qué rama tomó el último «si»: 0 ninguna, 1 si, 2 sino */
    jmp_buf jb;
    char *error;
} Contexto;

static void rt_error(Contexto *ctx, char *msg) __attribute__((noreturn));
static void rt_error(Contexto *ctx, char *msg) {
    ctx->error = msg;
    longjmp(ctx->jb, 1);
}

static Valor defecto(int t) {
    if (es_arr(t)) {
        Lista *l = xmalloc(sizeof(Lista));
        l->elem = base_de(t);
        return v_lista(l);
    }
    switch (t) {
    case T_ENTERO: return v_ent(0);
    case T_DECIMAL: return v_dec(0.0);
    case T_TEXTO: return v_txt("");
    default: return v_log(0);
    }
}

/* repr(round(x, 10)) de Python: 3.0 -> "3.0", 0.1 -> "0.1", 1e16 -> "1e+16" */
static char *repr_decimal(double v) {
    if (isnan(v)) return "nan";
    if (isinf(v)) return v < 0 ? "-inf" : "inf";
    char buf[512];
    snprintf(buf, sizeof buf, "%.10f", v);                      /* redondea a 10 decimales */
    double r = strtod(buf, NULL);
    int neg = signbit(r) != 0;
    double a = fabs(r);
    if (a == 0.0) return neg ? "-0.0" : "0.0";

    char e[64];
    int prec;
    for (prec = 0; prec < 17; prec++) {                         /* menos dígitos que recuperen el mismo valor */
        snprintf(e, sizeof e, "%.*e", prec, a);
        if (strtod(e, NULL) == a) break;
    }
    char digitos[32];
    int nd = 0;
    char *p = e;
    while (*p && *p != 'e') { if (*p != '.') digitos[nd++] = *p; p++; }
    digitos[nd] = 0;
    while (nd > 1 && digitos[nd - 1] == '0') digitos[--nd] = 0;
    int exp10 = atoi(p + 1);
    int decpt = exp10 + 1;

    char *out = neg ? "-" : "";
    if (decpt > -4 && decpt <= 16) {
        if (decpt <= 0) {
            out = sf("%s0.", out);
            for (int i = 0; i < -decpt; i++) out = sf("%s0", out);
            out = sf("%s%s", out, digitos);
        } else if (decpt >= nd) {
            out = sf("%s%s", out, digitos);
            for (int i = 0; i < decpt - nd; i++) out = sf("%s0", out);
            out = sf("%s.0", out);
        } else {
            out = sf("%s%.*s.%s", out, decpt, digitos, digitos + decpt);
        }
    } else {
        out = sf("%s%c", out, digitos[0]);
        if (nd > 1) out = sf("%s.%s", out, digitos + 1);
        out = sf("%se%c%02d", out, exp10 < 0 ? '-' : '+', abs(exp10));
    }
    return out;
}

static char *fmt_lista(const Lista *l);

/* Formato de un valor en la tabla de símbolos (los textos llevan comillas) */
static char *fmt_valor_tipo(Valor v, int t) {
    if (es_arr(t) || v.tag == V_LISTA) return fmt_lista(v.u.l);
    switch (t) {
    case T_LOGICO: return v.u.i ? "verdadero" : "falso";
    case T_TEXTO: return sf("\"%s\"", v.u.s);
    case T_DECIMAL: return repr_decimal(a_dec(v));
    default: return sf("%lld", v.u.i);
    }
}

/* Formato de un valor para «mostrar» (sin comillas en los textos) */
static char *fmt_mostrar(Valor v) {
    switch (v.tag) {
    case V_LOGICO: return v.u.i ? "verdadero" : "falso";
    case V_DECIMAL: return repr_decimal(v.u.d);
    case V_TEXTO: return (char *)v.u.s;
    case V_LISTA: return fmt_lista(v.u.l);
    case V_ENTERO: return sf("%lld", v.u.i);
    default: return "";
    }
}

static char *fmt_lista(const Lista *l) {
    char *out = "[";
    for (int i = 0; i < l->n; i++) {
        Valor v = l->v[i];
        int t = v.tag == V_TEXTO ? T_TEXTO : v.tag == V_DECIMAL ? T_DECIMAL :
                v.tag == V_LOGICO ? T_LOGICO : T_ENTERO;
        out = sf("%s%s%s", out, i ? ", " : "", fmt_valor_tipo(v, t));
    }
    return sf("%s]", out);
}

static Valor evaluar(Nodo *n, Entorno *env, Contexto *ctx);
static void exec_stmt(Nodo *s, Entorno *env, Contexto *ctx, Valor *res);

static int add_evento(Contexto *ctx, int tipo, int linea, char *texto) {
    Evento *e = xmalloc(sizeof(Evento));
    e->tipo = tipo;
    e->linea = linea;
    e->texto = texto;
    vec_push(&ctx->eventos, e);
    return ctx->eventos.n - 1;
}

static int comparar_num(Valor a, Valor b) {
    if (a.tag == V_ENTERO && b.tag == V_ENTERO) return a.u.i < b.u.i ? -1 : a.u.i > b.u.i;
    double x = a_dec(a), y = a_dec(b);
    return x < y ? -1 : x > y;
}

static int son_iguales(Valor a, Valor b) {
    if (a.tag == V_TEXTO) return strcmp(a.u.s, b.u.s) == 0;
    if (a.tag == V_LOGICO) return a.u.i == b.u.i;
    return comparar_num(a, b) == 0;
}

static Valor aritmetica(Nodo *n, Valor a, Valor b, Contexto *ctx) {
    const char *op = n->valor;
    char c = op[0];
    if (c == '+' && a.tag == V_TEXTO) return v_txt(sf("%s%s", a.u.s, b.u.s));   /* concatenación */
    if (c == '/') {
        double y = a_dec(b);
        if (y == 0)
            rt_error(ctx, sf("División entre cero (línea %d)", n->linea));
        return v_dec(a_dec(a) / y);
    }
    if (a.tag == V_ENTERO && b.tag == V_ENTERO) {
        long long r;
        int desborda = c == '+' ? __builtin_add_overflow(a.u.i, b.u.i, &r) :
                       c == '-' ? __builtin_sub_overflow(a.u.i, b.u.i, &r) :
                                  __builtin_mul_overflow(a.u.i, b.u.i, &r);
        if (desborda)
            rt_error(ctx, sf("Desbordamiento: el resultado no cabe en un entero (línea %d)", n->linea));
        return v_ent(r);
    }
    double x = a_dec(a), y = a_dec(b);
    return v_dec(c == '+' ? x + y : c == '-' ? x - y : x * y);
}

static Valor llamar(Nodo *n, Entorno *env, Contexto *ctx);

static Valor evaluar(Nodo *n, Entorno *env, Contexto *ctx) {
    switch (n->k) {
    case N_LIT_ENT: return v_ent(strtoll(n->valor, NULL, 10));
    case N_LIT_DEC: return v_dec(strtod(n->valor, NULL));
    case N_LIT_TXT: return v_txt(n->valor);
    case N_LIT_LOG: return v_log(!strcmp(n->valor, "verdadero"));
    case N_VARIABLE: return entorno_obtener(env, n->valor)->v;
    case N_LLAMADA: return llamar(n, env, ctx);
    case N_UNARIO: {
        Valor a = evaluar(H(n, 0), env, ctx);
        if (a.tag == V_DECIMAL) return v_dec(-a.u.d);
        if (a.u.i == LLONG_MIN)
            rt_error(ctx, sf("Desbordamiento: el resultado no cabe en un entero (línea %d)", n->linea));
        return v_ent(-a.u.i);
    }
    case N_LISTA: {
        Lista *l = xmalloc(sizeof(Lista));
        l->elem = base_de(n->tipo_dato);
        for (int i = 0; i < NH(n); i++) {
            Valor v = evaluar(H(n, i), env, ctx);
            if (l->elem == T_DECIMAL && v.tag == V_ENTERO) v = v_dec((double)v.u.i);
            lista_push(l, v);
        }
        return v_lista(l);
    }
    case N_INDICE: {
        Valor b = evaluar(H(n, 0), env, ctx);
        Valor i = evaluar(H(n, 1), env, ctx);
        if (i.u.i < 0 || i.u.i >= b.u.l->n)
            rt_error(ctx, sf("Índice fuera de rango: %lld (el arreglo tiene %d elemento%s) (línea %d)",
                             i.u.i, b.u.l->n, b.u.l->n == 1 ? "" : "s", n->linea));
        return b.u.l->v[i.u.i];
    }
    default:
        break;
    }
    /* BinOp */
    Valor a = evaluar(H(n, 0), env, ctx);
    Valor b = evaluar(H(n, 1), env, ctx);
    const char *op = n->valor;
    if (!strcmp(op, "==")) return v_log(son_iguales(a, b));
    if (!strcmp(op, "!=")) return v_log(!son_iguales(a, b));
    if (!strcmp(op, "<")) return v_log(comparar_num(a, b) < 0);
    if (!strcmp(op, ">")) return v_log(comparar_num(a, b) > 0);
    if (!strcmp(op, "<=")) return v_log(comparar_num(a, b) <= 0);
    if (!strcmp(op, ">=")) return v_log(comparar_num(a, b) >= 0);
    return aritmetica(n, a, b, ctx);
}

static char *mayusculas(const char *s) {
    char *out = xmalloc(strlen(s) * 2 + 1);
    size_t o = 0;
    for (size_t i = 0; s[i];) {
        int len;
        unsigned cp = decodificar(s + i, &len);
        if (cp >= 'a' && cp <= 'z') cp -= 32;
        else if (cp == 0xDF) { out[o++] = 'S'; cp = 'S'; }                       /* ß -> SS */
        else if (cp >= 0xE0 && cp <= 0xFE && cp != 0xF7) cp -= 32;               /* á é ñ ü ... */
        else if (cp == 0xFF) cp = 0x178;
        o += (size_t)codificar(cp, out + o);
        i += (size_t)len;
    }
    out[o] = 0;
    return out;
}

static char *minusculas(const char *s) {
    char *out = xmalloc(strlen(s) * 2 + 1);
    size_t o = 0;
    for (size_t i = 0; s[i];) {
        int len;
        unsigned cp = decodificar(s + i, &len);
        if (cp >= 'A' && cp <= 'Z') cp += 32;
        else if (cp >= 0xC0 && cp <= 0xDE && cp != 0xD7) cp += 32;               /* Á É Ñ Ü ... */
        o += (size_t)codificar(cp, out + o);
        i += (size_t)len;
    }
    out[o] = 0;
    return out;
}

/* Da vuelta el texto sin partir los caracteres con acento (UTF-8) */
static char *invertir(const char *s) {
    size_t n = strlen(s), o = 0, i = n;
    char *out = xmalloc(n + 1);
    while (i > 0) {
        size_t j = i - 1;
        while (j > 0 && ((unsigned char)s[j] & 0xC0) == 0x80) j--;
        memcpy(out + o, s + j, i - j);
        o += i - j;
        i = j;
    }
    return out;
}

/* subtexto("Costa Rica", 6, 4) da "Rica": empieza en 0; si se pasa del final, corta ahí */
static char *subtexto(const char *s, long long ini, long long cant) {
    if (ini < 0) ini = 0;
    if (cant < 0) cant = 0;
    const char *p = s;
    for (long long i = 0; *p && i < ini; i++) { int l; decodificar(p, &l); p += l; }
    const char *q = p;
    for (long long c = 0; *q && c < cant; c++) { int l; decodificar(q, &l); q += l; }
    return sndup(p, (size_t)(q - p));
}

static Valor llamar_predef(const char *nombre, Valor *args, int na, Nodo *n, Contexto *ctx) {
    if (!strcmp(nombre, "mostrar")) {
        char *texto = "";
        for (int i = 0; i < na; i++) texto = sf("%s%s%s", texto, i ? " " : "", fmt_mostrar(args[i]));
        vec_push(&ctx->salida, texto);
        add_evento(ctx, 1, n->linea, texto);
        return v_none();
    }
    if (!strcmp(nombre, "longitud"))
        return v_ent(args[0].tag == V_LISTA ? args[0].u.l->n : ulen(args[0].u.s));
    if (!strcmp(nombre, "mayusculas")) return v_txt(mayusculas(args[0].u.s));
    if (!strcmp(nombre, "redondear")) {                  /* los .5 se redondean hacia arriba */
        double r = floor(a_dec(args[0]) + 0.5);
        if (!(r >= -9.2e18 && r <= 9.2e18))
            rt_error(ctx, sf("El número es demasiado grande para redondearlo a entero (línea %d)", n->linea));
        return v_ent((long long)r);
    }
    if (!strcmp(nombre, "absoluto")) {
        if (args[0].tag == V_DECIMAL) return v_dec(fabs(args[0].u.d));
        if (args[0].u.i == LLONG_MIN)
            rt_error(ctx, sf("Desbordamiento: el resultado no cabe en un entero (línea %d)", n->linea));
        return v_ent(args[0].u.i < 0 ? -args[0].u.i : args[0].u.i);
    }
    if (!strcmp(nombre, "minusculas")) return v_txt(minusculas(args[0].u.s));
    if (!strcmp(nombre, "invertir")) return v_txt(invertir(args[0].u.s));
    if (!strcmp(nombre, "contiene")) return v_log(strstr(args[0].u.s, args[1].u.s) != NULL);
    if (!strcmp(nombre, "subtexto")) return v_txt(subtexto(args[0].u.s, args[1].u.i, args[2].u.i));
    if (!strcmp(nombre, "aTexto")) return v_txt(fmt_mostrar(args[0]));
    if (!strcmp(nombre, "raiz")) {
        double x = a_dec(args[0]);
        if (x < 0)
            rt_error(ctx, sf("No existe la raíz cuadrada de un número negativo (línea %d)", n->linea));
        return v_dec(sqrt(x));
    }
    if (!strcmp(nombre, "potencia")) {
        double r = pow(a_dec(args[0]), a_dec(args[1]));
        if (!isfinite(r))
            rt_error(ctx, sf("La potencia no tiene un resultado válido (línea %d)", n->linea));
        return v_dec(r);
    }
    if (!strcmp(nombre, "minimo") || !strcmp(nombre, "maximo")) {
        Valor a = args[0], b = args[1];
        int cmp = comparar_num(b, a);
        Valor r = (!strcmp(nombre, "maximo") ? cmp > 0 : cmp < 0) ? b : a;
        if (a.tag == V_ENTERO && b.tag == V_ENTERO) return r;
        return v_dec(a_dec(r));
    }
    if (!strcmp(nombre, "agregar")) {
        Lista *l = args[0].u.l;
        Valor v = args[1];
        if (l->elem == T_DECIMAL && v.tag == V_ENTERO) v = v_dec((double)v.u.i);
        lista_push(l, v);
        return v_none();
    }
    /* quitar */
    Lista *l = args[0].u.l;
    if (l->n == 0)
        rt_error(ctx, sf("No se puede quitar un elemento de un arreglo vacío (línea %d)", n->linea));
    return l->v[--l->n];
}

static Valor llamar(Nodo *n, Entorno *env, Contexto *ctx) {
    int na = NH(n);
    Valor *args = xmalloc(sizeof(Valor) * (size_t)(na ? na : 1));
    for (int i = 0; i < na; i++) args[i] = evaluar(H(n, i), env, ctx);      /* primero los argumentos */
    if (buscar_predef(n->nombre)) return llamar_predef(n->nombre, args, na, n, ctx);

    Nodo *f = NULL;
    for (int i = 0; i < ctx->funciones.n; i++)
        if (!strcmp(((Nodo *)ctx->funciones.v[i])->nombre, n->nombre)) f = ctx->funciones.v[i];

    ctx->profundidad++;
    if (ctx->profundidad > MAX_LLAMADAS)
        rt_error(ctx, sf("Recursión demasiado profunda: más de %d llamadas anidadas a «%s» (línea %d). "
                         "¿Falta el caso base?", MAX_LLAMADAS, n->nombre, n->linea));
    Entorno *local = entorno_nuevo(NULL);          /* ámbito nuevo: no ve las variables globales */
    for (int i = 0; i < f->np; i++) {
        Valor v = args[i];
        if (H(f, i)->tipo_decl == T_DECIMAL && v.tag == V_ENTERO) v = v_dec((double)v.u.i);
        entorno_declarar(local, H(f, i)->nombre, v);
    }
    ctx->valor_ret = v_none();
    for (int i = f->np; i < NH(f); i++) {
        Valor ignorado;
        exec_stmt(H(f, i), local, ctx, &ignorado);
        if (ctx->retornando) break;
    }
    ctx->retornando = 0;
    ctx->profundidad--;
    Valor valor = ctx->valor_ret;
    ctx->valor_ret = v_none();
    if (f->tipo_ret == T_DECIMAL && valor.tag == V_ENTERO) valor = v_dec((double)valor.u.i);
    return valor;
}

static void ejecutar_bloque(Nodo *bloque_, Entorno *env, Contexto *ctx) {
    Entorno *local = entorno_nuevo(env);           /* las variables del bloque viven solo aquí */
    for (int i = 0; i < NH(bloque_); i++) {
        Valor ignorado;
        exec_stmt(H(bloque_, i), local, ctx, &ignorado);
        if (ctx->retornando) return;
    }
}

static void exec_stmt(Nodo *s, Entorno *env, Contexto *ctx, Valor *res) {
    *res = v_none();
    switch (s->k) {
    case N_DECL: {
        int t = s->tipo_decl;
        Valor v = NH(s) ? evaluar(H(s, 0), env, ctx) : defecto(t);
        if (t == T_DECIMAL && v.tag == V_ENTERO) v = v_dec((double)v.u.i);
        entorno_declarar(env, s->nombre, v);
        *res = v;
        break;
    }
    case N_ASIG: {
        Valor v = evaluar(H(s, 0), env, ctx);
        if (s->tipo_dato == T_DECIMAL && v.tag == V_ENTERO) v = v_dec((double)v.u.i);
        entorno_obtener(env, s->nombre)->v = v;
        *res = v;
        break;
    }
    case N_ASIG_IDX: {
        Valor i = evaluar(H(s, 0), env, ctx);
        Valor v = evaluar(H(s, 1), env, ctx);
        Lista *l = entorno_obtener(env, s->nombre)->v.u.l;
        if (i.u.i < 0 || i.u.i >= l->n)
            rt_error(ctx, sf("Índice fuera de rango: %lld (el arreglo tiene %d elemento%s) (línea %d)",
                             i.u.i, l->n, l->n == 1 ? "" : "s", s->linea));
        if (l->elem == T_DECIMAL && v.tag == V_ENTERO) v = v_dec((double)v.u.i);
        l->v[i.u.i] = v;
        *res = v;
        break;
    }
    case N_LLAMADA:
        *res = llamar(s, env, ctx);
        break;
    case N_RETORNO:
        ctx->valor_ret = NH(s) ? evaluar(H(s, 0), env, ctx) : v_none();
        ctx->retornando = 1;
        break;
    case N_SI: {                                   /* guarda qué rama se ejecutó */
        int rama = 0;
        if (evaluar(H(s, 0), env, ctx).u.i) {
            rama = 1;
            ejecutar_bloque(H(s, 1), env, ctx);
        } else if (NH(s) == 3) {
            rama = 2;
            ejecutar_bloque(H(s, 2), env, ctx);
        }
        ctx->rama = rama;                          /* después del bloque: un «sino si» interno no la pisa */
        break;
    }
    default:
        break;
    }
}

static void ejecutar(Nodo *raiz, Semantico *S, Contexto *ctx) {
    Entorno *env = entorno_nuevo(NULL);
    for (int i = 0; i < NH(raiz); i++) {
        Nodo *s = H(raiz, i);
        if (s->k == N_FUNCION) {
            vec_push(&ctx->funciones, s);
            add_evento(ctx, 0, s->linea, sf("función «%s» definida", s->nombre));
            continue;
        }
        int ev = add_evento(ctx, 0, s->linea, "✘ interrumpida por un error");
        Valor v;
        exec_stmt(s, env, ctx, &v);
        char *txt;
        if (s->k == N_DECL) {
            txt = sf("%s = %s", s->nombre, fmt_valor_tipo(v, s->tipo_decl));
            Simbolo *sim = ambito_buscar(S->globales, s->nombre);
            sim->valor_inicial = sf("%s%s", fmt_valor_tipo(v, s->tipo_decl), NH(s) ? "" : "  (por defecto)");
        } else if (s->k == N_ASIG) {
            txt = sf("%s = %s", s->nombre, fmt_valor_tipo(v, s->tipo_dato));
        } else if (s->k == N_ASIG_IDX) {
            txt = sf("%s = %s", s->nombre, fmt_lista(entorno_obtener(env, s->nombre)->v.u.l));
        } else if (s->k == N_SI) {
            txt = ctx->rama == 1 ? "condición verdadera → se ejecuta el bloque «si»" :
                  ctx->rama == 2 ? "condición falsa → se ejecuta el bloque «sino»" :
                                   "condición falsa → no se ejecuta ningún bloque";
        } else {
            txt = sf("llamada a %s", s->nombre);
        }
        ((Evento *)ctx->eventos.v[ev])->texto = txt;
    }
    for (int i = 0; i < env->vars.n; i++) {
        Var *x = env->vars.v[i];
        Simbolo *sim = ambito_buscar(S->globales, x->nombre);
        if (sim) sim->valor_final = fmt_valor_tipo(x->v, sim->tipo);
    }
}

/* =========================================================================
 * Presentación: AST Table, árbol, Tabla de Símbolos, errores
 * ========================================================================= */
typedef struct { int nc; char **cab; Vec filas; } Tabla;

static Tabla *tabla_nueva(int nc, ...) {
    Tabla *t = xmalloc(sizeof(Tabla));
    t->nc = nc;
    t->cab = xmalloc(sizeof(char *) * (size_t)nc);
    va_list ap;
    va_start(ap, nc);
    for (int i = 0; i < nc; i++) t->cab[i] = va_arg(ap, char *);
    va_end(ap);
    return t;
}

static void tabla_fila(Tabla *t, ...) {
    char **f = xmalloc(sizeof(char *) * (size_t)t->nc);
    va_list ap;
    va_start(ap, t);
    for (int i = 0; i < t->nc; i++) f[i] = va_arg(ap, char *);
    va_end(ap);
    vec_push(&t->filas, f);
}

static void tabla_imprimir(Tabla *t) {
    int *an = xmalloc(sizeof(int) * (size_t)t->nc);
    for (int i = 0; i < t->nc; i++) {
        an[i] = ulen(t->cab[i]);
        for (int r = 0; r < t->filas.n; r++) {
            int w = ulen(((char **)t->filas.v[r])[i]);
            if (w > an[i]) an[i] = w;
        }
    }
    char *sep = "+";
    for (int i = 0; i < t->nc; i++) {
        for (int k = 0; k < an[i] + 2; k++) sep = sf("%s-", sep);
        sep = sf("%s+", sep);
    }
    puts(sep);
    printf("| ");
    for (int i = 0; i < t->nc; i++) { pr_pad(t->cab[i], an[i]); printf(i + 1 < t->nc ? " | " : " |\n"); }
    puts(sep);
    for (int r = 0; r < t->filas.n; r++) {
        char **f = t->filas.v[r];
        printf("| ");
        for (int i = 0; i < t->nc; i++) { pr_pad(f[i], an[i]); printf(i + 1 < t->nc ? " | " : " |\n"); }
    }
    puts(sep);
}

/* AST Table: numera los nodos en preorden */
static void numerar(Nodo *n, int padre, Vec *lista) {
    vec_push(lista, n);
    n->id = lista->n;
    n->padre = padre;
    for (int i = 0; i < NH(n); i++) numerar(H(n, i), n->id, lista);
}

static char *valor_txt(const Nodo *n) {
    if (n->k == N_LIT_TXT) return sf("\"%s\"", n->valor);
    return n->valor ? n->valor : "";
}

static void arbol_imp(Nodo *n, const char *prefijo, int ultimo, int es_raiz) {
    char *etiqueta = sf("%s", NODO_NOMBRE[n->k]);
    if (n->valor) etiqueta = sf("%s [%s]", etiqueta, valor_txt(n));
    if (n->tipo_dato && n->k != N_DECL && n->k != N_PARAM)
        etiqueta = sf("%s : %s", etiqueta, tipo_nombre(n->tipo_dato));
    const char *nuevo;
    if (es_raiz) {
        puts(etiqueta);
        nuevo = "";
    } else {
        printf("%s%s%s\n", prefijo, ultimo ? "└── " : "├── ", etiqueta);
        nuevo = sf("%s%s", prefijo, ultimo ? "    " : "│   ");
    }
    for (int i = 0; i < NH(n); i++) arbol_imp(H(n, i), nuevo, i == NH(n) - 1, 0);
}

static void titulo(const char *txt) {
    printf("\n======================================================================\n%s\n"
           "======================================================================\n", txt);
}

static int cmp_errores(const void *a, const void *b) {
    const ErrorAlex *x = *(ErrorAlex *const *)a, *y = *(ErrorAlex *const *)b;
    if (x->linea != y->linea) return x->linea - y->linea;
    if (x->col != y->col) return x->col - y->col;
    return x->orden - y->orden;                    /* orden estable */
}

static void reportar(Vec *errores, Vec *lineas) {
    qsort(errores->v, (size_t)errores->n, sizeof(void *), cmp_errores);
    for (int i = 0; i < errores->n; i++) {
        ErrorAlex *e = errores->v[i];
        printf("  ✘ Error %s (línea %d", e->fase, e->linea);
        if (e->col) printf(", columna %d", e->col);
        printf("): %s\n", e->mensaje);
        if (e->linea >= 1 && e->linea <= lineas->n) {
            printf("      %s\n", (char *)lineas->v[e->linea - 1]);
            if (e->col) printf("      %*s^\n", e->col - 1, "");
        }
    }
}

static char *firma_params(const InfoFuncion *info) {
    if (info->np == 0) return "-";
    char *txt = "";
    for (int i = 0; i < info->np; i++) {
        int t = info->params[i].tipo;
        const char *ts = t == P_ANY ? "cualquiera" : t == P_NUM ? "número" :
                         t == P_TEXTO_O_ARR ? "texto o arreglo" : t == P_ARR ? "arreglo" :
                         t == P_ELEM ? "elemento" : tipo_nombre(t);
        txt = sf("%s%s%s: %s", txt, i ? ", " : "", info->params[i].nombre, ts);
    }
    return info->variadica ? sf("%s, ...", txt) : txt;
}

static void mostrar_funciones(Semantico *S) {
    Vec infos = {0};
    for (int i = 0; i < S->funciones.n; i++) vec_push(&infos, S->funciones.v[i]);
    for (int i = 0; i < S->predef.n; i++)
        if (((InfoFuncion *)S->predef.v[i])->llamadas > 0) vec_push(&infos, S->predef.v[i]);
    if (!infos.n) return;
    Tabla *t = tabla_nueva(6, "Función", "Origen", "Parámetros", "Retorna", "Línea", "Llamadas");
    for (int i = 0; i < infos.n; i++) {
        InfoFuncion *f = infos.v[i];
        const char *ret = f->ret == T_NONE ? "-" : f->ret == R_ARG ? "(igual al argumento)" :
                          f->ret == R_ELEM ? "(tipo de los elementos)" :
                          f->ret == R_NUM2 ? "(entero o decimal)" : tipo_nombre(f->ret);
        tabla_fila(t, f->nombre, f->predefinida ? "predefinida" : "propia", firma_params(f), ret,
                   f->predefinida ? "-" : sf("%d", f->linea), sf("%d", f->llamadas));
    }
    printf("\nTabla de funciones:\n");
    tabla_imprimir(t);
}

static void mostrar_simbolos(Semantico *S, int con_valores) {
    Tabla *t = con_valores
        ? tabla_nueva(9, "Nombre", "Tipo", "Clase", "Ámbito", "Línea", "Asign.", "Lect.",
                      "Valor inicial", "Valor final")
        : tabla_nueva(7, "Nombre", "Tipo", "Clase", "Ámbito", "Línea", "Asign.", "Lect.");
    for (int i = 0; i < S->simbolos.n; i++) {
        Simbolo *s = S->simbolos.v[i];
        if (con_valores)
            tabla_fila(t, s->nombre, tipo_nombre(s->tipo), s->clase, s->ambito, sf("%d", s->linea),
                       sf("%d", s->asignaciones), sf("%d", s->lecturas),
                       s->valor_inicial ? s->valor_inicial : "-", s->valor_final ? s->valor_final : "-");
        else
            tabla_fila(t, s->nombre, tipo_nombre(s->tipo), s->clase, s->ambito, sf("%d", s->linea),
                       sf("%d", s->asignaciones), sf("%d", s->lecturas));
    }
    tabla_imprimir(t);
    mostrar_funciones(S);
}

/* Parte el texto en líneas (como splitlines: sin la línea vacía final) */
static Vec *separar_lineas(const char *f) {
    Vec *v = xmalloc(sizeof(Vec));
    size_t n = strlen(f), ini = 0;
    for (size_t i = 0; i <= n; i++) {
        if (i == n || f[i] == '\n') {
            if (i == n && i == ini) break;
            size_t fin = i;
            if (fin > ini && f[fin - 1] == '\r') fin--;
            vec_push(v, sndup(f + ini, fin - ini));
            ini = i + 1;
        }
    }
    return v;
}

/* =========================================================================
 * Programa principal
 * ========================================================================= */
static int compilar(const char *fuente, int ver_tokens) {
    Vec *lineas = separar_lineas(fuente);

    titulo("FASE 1: ANÁLISIS LÉXICO");
    Vec tokens = {0}, errs = {0};
    analizar_lexico(fuente, &tokens, &errs);
    if (ver_tokens) {
        Tabla *t = tabla_nueva(4, "Línea", "Col", "Token", "Lexema");
        for (int i = 0; i < tokens.n; i++) {
            Token *k = tokens.v[i];
            if (k->tipo != TK_EOF)
                tabla_fila(t, sf("%d", k->linea), sf("%d", k->col), (char *)TOK_NOMBRE[k->tipo], k->valor);
        }
        tabla_imprimir(t);
    }
    if (errs.n) {
        reportar(&errs, lineas);
        printf("\nCompilación detenida: %d error(es) léxico(s).\n", errs.n);
        return 1;
    }
    printf("  ✔ %d tokens reconocidos, sin errores léxicos.\n", tokens.n - 1);

    titulo("FASE 2: ANÁLISIS SINTÁCTICO  (AST)");
    Parser P = {0};
    P.t = (Token **)tokens.v;
    Vec perrores = {0};
    P.errores = &perrores;
    Nodo *raiz = programa(&P);
    if (perrores.n) {
        reportar(&perrores, lineas);
        printf("\nCompilación detenida: %d error(es) sintáctico(s).\n", perrores.n);
        return 1;
    }
    printf("  ✔ La estructura del programa es correcta.\n\n");

    Semantico S = {0};
    S.globales = ambito_nuevo("global");
    vec_push(&S.pila, S.globales);
    for (int i = 0; i < NH(raiz); i++) sem_sentencia(&S, H(raiz, i));
    Vec nodos = {0};
    numerar(raiz, 0, &nodos);
    printf("Árbol sintáctico (AST):\n");
    arbol_imp(raiz, "", 1, 1);

    titulo("AST TABLE");
    Tabla *ta = tabla_nueva(7, "ID", "Nodo", "Valor", "Tipo dato", "Padre", "Hijos", "Línea");
    for (int i = 0; i < nodos.n; i++) {
        Nodo *n = nodos.v[i];
        char *hijos = "";
        for (int h = 0; h < NH(n); h++) hijos = sf("%s%s%d", hijos, h ? "," : "", H(n, h)->id);
        tabla_fila(ta, sf("%d", n->id), (char *)NODO_NOMBRE[n->k], valor_txt(n),
                   n->tipo_dato ? (char *)tipo_nombre(n->tipo_dato) : "-",
                   n->padre ? sf("%d", n->padre) : "-", NH(n) ? hijos : "-", sf("%d", n->linea));
    }
    tabla_imprimir(ta);

    titulo("FASE 3: ANÁLISIS SEMÁNTICO");
    if (S.errores.n) {
        reportar(&S.errores, lineas);
        printf("\nTabla de Símbolos (hasta donde se pudo analizar):\n");
        mostrar_simbolos(&S, 0);
        printf("\nCompilación detenida: %d error(es) semántico(s).\n", S.errores.n);
        return 1;
    }
    printf("  ✔ Variables y funciones declaradas antes de usarse, sin duplicados, "
           "con tipos, argumentos, condiciones y retornos correctos.\n");

    titulo("FASE 4: EJECUCIÓN");
    Contexto *ctx = xmalloc(sizeof(Contexto));
    if (setjmp(ctx->jb) == 0) ejecutar(raiz, &S, ctx);
    for (int i = 0; i < ctx->eventos.n; i++) {
        Evento *e = ctx->eventos.v[i];
        if (e->tipo == 0) {
            char *src = e->linea <= lineas->n ? strip_copia(lineas->v[e->linea - 1]) : "";
            printf("  L%-3d ", e->linea);
            pr_pad(src, 45);
            printf(" →  %s\n", e->texto);
        } else {
            printf("       ▶ SALIDA: %s\n", e->texto);
        }
    }
    if (ctx->error) {
        printf("  ✘ Error de ejecución: %s\n", ctx->error);
        return 1;
    }

    if (ctx->salida.n) {
        titulo("SALIDA DEL PROGRAMA");
        for (int i = 0; i < ctx->salida.n; i++) printf("  %s\n", (char *)ctx->salida.v[i]);
    }

    titulo("TABLA DE SÍMBOLOS");
    mostrar_simbolos(&S, 1);
    printf("\n");
    return 0;
}

static char *leer_archivo(const char *ruta) {
    FILE *f = fopen(ruta, "rb");
    if (!f) return NULL;
    size_t cap = 4096, n = 0;
    char *buf = xmalloc(cap);
    size_t r;
    while ((r = fread(buf + n, 1, cap - n - 1, f)) > 0) {
        n += r;
        if (n + 1 >= cap) { cap *= 2; buf = xrealloc(buf, cap); }
    }
    fclose(f);
    buf[n] = 0;
    if (n >= 3 && (unsigned char)buf[0] == 0xEF && (unsigned char)buf[1] == 0xBB && (unsigned char)buf[2] == 0xBF)
        memmove(buf, buf + 3, n - 2);              /* se ignora la marca BOM de UTF-8 */
    return buf;
}

int main(int argc, char **argv) {
#ifdef _WIN32
    SetConsoleOutputCP(65001);
#endif
    const char *archivo = NULL;
    int ver_tokens = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--tokens")) ver_tokens = 1;
        else if (!archivo) archivo = argv[i];
        else archivo = NULL, i = argc;
    }
    if (!archivo) {
        fprintf(stderr, "uso: %s archivo.alex [--tokens]\n", argv[0]);
        return 2;
    }
    char *fuente = leer_archivo(archivo);
    if (!fuente) {
        fprintf(stderr, "%s: no se pudo abrir «%s»\n", argv[0], archivo);
        return 2;
    }
    return compilar(fuente, ver_tokens);
}
