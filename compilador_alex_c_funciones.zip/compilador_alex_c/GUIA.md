# Compilador de ALEX: guía paso a paso

Estudiante: Alexis Viquez Terranova · Compiladores · Prof. William Martinez

## 0. Cómo compilarlo y correrlo

El compilador está escrito en C (`alex.c`). Primero se compila una vez:

```
sudo apt install build-essential   # solo la primera vez en Ubuntu (gcc y make)
make                               # compila alex.c y deja el ejecutable ./alex
make probar                        # corre todos los ejemplos y comprueba el resultado esperado
```

Después se usa así:

```
./alex ejemplos/ok.alex              # programa correcto: AST, AST Table, símbolos y ejecución
./alex ejemplos/ok.alex --tokens     # igual, mostrando también la tabla de tokens
./alex ejemplos/err_lexico.alex      # errores léxicos
./alex ejemplos/err_sintactico.alex  # errores sintácticos
./alex ejemplos/err_semantico.alex   # errores semánticos
./alex ejemplos/funciones.alex       # funciones propias y predefinidas
./alex ejemplos/err_func_sintactico.alex  # errores sintácticos en funciones
./alex ejemplos/err_func_semantico.alex   # errores semánticos en funciones
./alex ejemplos/condicionales.alex   # si / sino, comparaciones y recursión
./alex ejemplos/err_si_sintactico.alex    # errores sintácticos en si / sino
./alex ejemplos/err_si_semantico.alex     # errores semánticos en si / sino
./alex ejemplos/arreglos.alex        # arreglos: tipo[], indices, agregar, quitar, longitud
./alex ejemplos/mas_funciones.alex   # funciones predefinidas de números y de textos
./alex ejemplos/err_funciones_pred.alex   # errores de tipo en las funciones predefinidas
./alex ejemplos/err_raiz.alex        # raíz de un negativo (error al ejecutar)
./alex ejemplos/err_arr_sintactico.alex   # errores sintácticos en arreglos
./alex ejemplos/err_arr_semantico.alex    # errores semánticos en arreglos
./alex ejemplos/err_arr_ejecucion.alex    # índice fuera de rango (error al ejecutar)
./alex ejemplos/err_arr_vacio.alex        # quitar de un arreglo vacío (error al ejecutar)
```

Solo necesita `gcc` y `make` (sin librerías externas).

## 1. Las reglas de ALEX (lo que explicas en la evaluación)

| Regla | Detalle |
|---|---|
| Declarar | `dato nombre: tipo;` o `dato nombre: tipo = valor;` |
| Asignar | `nombre = expresion;` (la variable debe existir) |
| Fin de instrucción | Siempre `;` |
| Tipos | `entero` (7, -15), `decimal` (3.14), `texto` ("Hola"), `logico` (verdadero / falso) |
| Nombres | Empiezan con letra o `_`; distinguen mayúsculas; no pueden ser reservadas; no se repiten |
| Reservadas | dato, funcion, retornar, si, sino, entero, decimal, texto, logico, verdadero, falso |
| Valor por defecto | 0, 0.0, "" y falso |
| Compatibilidad | entero → decimal sí; decimal → entero no |
| Prohibido | `a = b = 3;` (asignación encadenada) |
| Comentarios | `// hasta el final de la línea` |
| Funciones propias | `funcion nombre(p: tipo, ...): tipo { ... retornar valor; }`; el tipo de retorno es opcional |
| Ámbito | Cada función tiene su propio ámbito: ve sus parámetros y sus variables locales, no las globales |
| Llamadas | `nombre(argumentos)` como instrucción o dentro de una expresión; los argumentos deben coincidir en cantidad y tipo |
| Funciones predefinidas | `mostrar`, `longitud`, `mayusculas`, `redondear`, `absoluto`, `agregar`, `quitar`, `minimo`, `maximo`, `raiz`, `potencia`, `minusculas`, `invertir`, `contiene`, `subtexto`, `aTexto` |
| Prohibido en funciones | Código después de un `retornar` que siempre se ejecuta, definir una función dentro de otra o dentro de un bloque |
| Recursión | Una función puede llamarse a sí misma; el `si` sirve de caso base (límite de 200 llamadas anidadas) |
| Comparaciones | `==  !=  <  >  <=  >=`; el resultado es `logico`. Los de orden solo comparan números; `==` y `!=` comparan dos del mismo tipo |
| Condicionales | `si (condicion) { ... } sino { ... }` y `sino si (condicion) { ... }`; la condición debe ser `logico` |
| Ámbito de bloque | Una variable declarada dentro de un bloque `si` o `sino` solo existe ahí; el bloque ve las variables que lo rodean |
| Arreglos | `dato notas: decimal[] = [8.5, 9, 7.25];` Tipos `entero[]`, `decimal[]`, `texto[]`, `logico[]`; todos los elementos son del mismo tipo; sin valor inicial empieza vacío |
| Índices | `notas[0]` lee y `notas[1] = 10;` cambia; el primer elemento es el 0 y el índice debe ser entero |
| Arreglos: funciones | `agregar(arreglo, valor)` agrega al final (push), `quitar(arreglo)` saca el último y lo devuelve (pop), `longitud(arreglo)` da la cantidad |
| Arreglos: referencia | Un arreglo se pasa por referencia: si una función lo cambia, el original cambia |
| Arreglos: prohibido | Arreglos dentro de arreglos, comparar con `==`, sumar arreglos; un `entero[]` no cabe en un `decimal[]` |

Operadores `+ - * /` y paréntesis: los incluí porque tus propios ejemplos usan `precio + 2.5` y `edad + 1`. `+` también concatena texto. `entero / entero` da decimal. Si el profesor pide solo lo de la actividad anterior, puedes decir que son una extensión mínima.

## 2. Las 4 fases (y dónde está cada una en `alex.c`)

| Fase | Entregable | Dónde está |
|---|---|---|
| 1. Léxica | Tokens | `analizar_lexico()` |
| 2. Sintáctica | Analizador sintáctico + árbol AST | `programa()`, `sentencia()`, `expresion()` y las demás reglas |
| 2b. | AST Table | `numerar()` + `compilar()` (tabla "AST TABLE") |
| 3. Semántica | Analizador semántico + Tabla de Símbolos | `sem_sentencia()`, `sem_tipo()` y `struct Simbolo` |
| 4. Ejecución | Correr el código fuente | `ejecutar()` |

### Fase 1: léxico
Lee el texto carácter por carácter y lo convierte en tokens: `DATO`, `TIPO`, `IDENT`, `ENTERO`, `DECIMAL`, `TEXTO`, `VERDADERO`, `FALSO`, `:`, `;`, `=`, `+ - * /`, `( )`, `{ }`, `,` y `[ ]`. Detecta: carácter no válido (`@`), decimal mal formado (`3.`), texto sin cerrar.

### Fase 2: sintáctico
Descendente recursivo: una función de C por regla de la gramática. Cuando una función encuentra un error, hace un `longjmp` al último punto seguro (`programa()` o `bloque()`), que lo anota y sigue.

```
programa    ::= { sentencia }
sentencia   ::= declaracion | asignacion | asig_indice | funcion | retorno | si | llamada ";"
declaracion ::= "dato" IDENT ":" tipo [ "=" expresion ] ";"
asignacion  ::= IDENT "=" expresion ";"
asig_indice ::= IDENT "[" expresion "]" "=" expresion ";"
funcion     ::= "funcion" IDENT "(" [ parametros ] ")" [ ":" tipo ] "{" { sentencia } "}"
parametros  ::= IDENT ":" tipo { "," IDENT ":" tipo }
tipo        ::= TIPO [ "[" "]" ]
retorno     ::= "retornar" [ expresion ] ";"
si          ::= "si" "(" expresion ")" bloque [ "sino" ( si | bloque ) ]
bloque      ::= "{" { sentencia } "}"
llamada     ::= IDENT "(" [ expresion { "," expresion } ] ")"
expresion   ::= suma { ("==" | "!=" | "<" | ">" | "<=" | ">=") suma }
suma        ::= termino { ("+" | "-") termino }
termino     ::= factor { ("*" | "/") factor }
factor      ::= "-" factor | ENTERO | DECIMAL | TEXTO | "verdadero" | "falso"
              | "[" [ expresion { "," expresion } ] "]"
              | ( llamada | IDENT | "(" expresion ")" ) { "[" expresion "]" }
```

La precedencia sale de la gramática: `*` y `/` están un nivel más abajo que `+` y `-`, así que se evalúan primero. Cuando hay un error, el parser lo reporta y salta hasta el siguiente `;` para seguir revisando (por eso puede mostrar varios errores en una corrida).

### AST Table
Cada nodo del árbol se numera (ID), con su tipo de nodo, valor, tipo de dato (lo llena el semántico), padre, hijos y línea. Sale justo después del árbol dibujado.

### Fase 3: semántico y Tabla de Símbolos
Recorre el AST en orden y lleva la tabla de símbolos por ámbito (`global` y uno por función): `nombre → tipo, clase, ámbito, línea, asignaciones, lecturas`. También lleva una tabla de funciones con su firma y cuántas veces se llamó. Verifica:
1. Variable declarada antes de usarse.
2. No declarada dos veces.
3. El valor coincide con el tipo (entero → decimal permitido, decimal → entero no).
4. Operadores válidos para los tipos (no se puede `"a" - "b"`).
5. Funciones: no se redefinen ni se llaman antes de definirlas, y los parámetros no se repiten.
6. Llamadas: la cantidad y el tipo de los argumentos coinciden con los parámetros, y una función sin valor no se usa dentro de una expresión.
7. Retornos: una función con tipo debe tener `retornar` en todos sus caminos con un valor de ese tipo (un `si` solo cuenta si su `sino` también retorna), no hay código después de un `retornar` que siempre se ejecuta, y `retornar` solo existe dentro de funciones.
8. Ámbitos: una función no ve las variables globales, y las variables de una función o de un bloque no existen afuera.
9. Condiciones: la condición de un `si` debe ser `logico`.
10. Comparaciones: `<  >  <=  >=` solo entre números; `==` y `!=` entre dos números o dos del mismo tipo.
11. Arreglos: solo se usan corchetes con arreglos, el índice es entero, todos los elementos son del mismo tipo, un literal `[1, 2]` toma el tipo de donde se guarda (`decimal[]` o `entero[]`), `agregar` recibe un valor del tipo de los elementos y no hay arreglos dentro de arreglos ni comparaciones con `==`.

Si hay errores semánticos no se ejecuta nada.

### Fase 4: ejecución
Recorre el AST, calcula las expresiones y guarda los valores. Cada llamada a una función crea un ámbito nuevo con sus parámetros; `retornar` sale de la función con su valor. Un `si` evalúa su condición y ejecuta solo uno de sus bloques, cada uno con su propio ámbito; en la ejecución se muestra cuál rama se tomó. Lo que imprime `mostrar` aparece en la ejecución y en el bloque "SALIDA DEL PROGRAMA". Al final la Tabla de Símbolos muestra valor inicial y valor final de cada variable global. Los arreglos son una lista que crece sola (`struct Lista`); `lista[i]` revisa que `i` esté dentro del rango y `quitar` revisa que el arreglo no esté vacío. También detecta división entre cero y enteros que se pasan del rango de 64 bits.

## 3. Guion para la evaluación (5 minutos)

1. Mostrar `ok.alex` y explicar las reglas de la sección 1 con 2 o 3 líneas del código.
2. Correr `./alex ejemplos/ok.alex --tokens`: señalar los tokens, el árbol, la AST Table, la ejecución y la Tabla de Símbolos.
3. Correr `err_sintactico.alex`: «falta el `;`», «asignación encadenada», «palabra reservada».
4. Correr `err_semantico.alex`: «no declarada», «redeclarada», «decimal en entero».
5. Mostrar `./alex ejemplos/arreglos.alex`: el arreglo `notas` pasa de `[8.5, 9.0, 7.25]` a `[8.5, 10.0, 7.25]`, y `agregar`, `quitar` y `longitud`.
6. Cerrar con el siguiente paso: agregar ciclos (`mientras`) para recorrer los arreglos, que serían una regla nueva en el parser y un caso nuevo en el semántico.

## 4. Si el profesor pide un cambio en vivo

- Palabra reservada nueva: agregar un valor al `enum` de tokens (`TK_...`), su nombre en `TOK_NOMBRE`, el `else if` de `analizar_lexico()` y `es_reservada_tok()`.
- Tipo nuevo: agregarlo al `enum` de tipos (`T_...`), a `tipo_nombre()`, `tipo_desde_nombre()`, `defecto()` y `fmt_valor_tipo()`, y a la lista de palabras de tipo de `analizar_lexico()`.
- Operador nuevo: añadirlo al `switch` de caracteres de `analizar_lexico()`, al parser (`expresion()`, `suma()` o `termino()`) y a `evaluar()` o `aritmetica()`.
- Función predefinida nueva: agregar una fila a la tabla `PREDEF[]` (nombre, parámetros y tipo de retorno) y escribir su comportamiento en `llamar_predef()`.
- Comparador nuevo: agregarlo al lexer (`analizar_lexico()`) y a `es_comparador()`, y darle su regla de tipos en `sem_tipo()` (caso `N_BINOP`) y su cálculo en `evaluar()`.
- Condicional nuevo (por ejemplo un ciclo `mientras`): reutiliza `bloque()` en el parser, `sem_bloque()` en el semántico y `ejecutar_bloque()` en la ejecución.
- Renombrar `agregar` o `quitar` (por ejemplo a `push` y `pop`): cambiar el nombre en la tabla `PREDEF[]` y en `llamar_predef()`; el resto no cambia.
- Otro tipo de elemento en los arreglos: ya funciona con cualquiera de los cuatro tipos, porque el tipo del arreglo es `tipo | 8`.
